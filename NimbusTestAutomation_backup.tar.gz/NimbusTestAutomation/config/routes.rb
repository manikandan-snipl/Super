Rails.application.routes.draw do
  # The priority is based upon order of creation: first created -> highest priority.
  # See how all your routes lay out with "rake routes".

  # You can have the root of your site routed with "root"
  # root 'welcome#index'
  mount CommonEngine::Engine => "/common_engine"
  mount NimbusAdminEngine::Engine => "/nimbus_admin_engine"
  get '/group_list', to: 'groups#group_list'
  get '/group_detail', to: 'groups#group_detail'
  get '/new_group', to: 'groups#new_group'
end
