#------------------------------------------------------------------------------
ENTITIES = %w(Account Campaign Contact Lead Opportunity).freeze

#COMMON_API_PATH = "http://52.0.212.17:5411/api/v1"
COMMON_API_PATH = "http://localhost:3005/cloud/api/v1"

# Base URL
BASE_URL = "http://52.0.212.17:5411"
MARKETING_BASE_PATH = "https://52.0.212.17"
#MARKETING_BASE_PATH = "https://localhost:3001"
FACE_WEB_ADMIN_PATH = "https://52.0.212.17"
#FACE_WEB_ADMIN_PATH = "https://localhost:3007"
# MARKETING_BASE_PATH = "http://52.6.96.181:7201"

BIG_DATA_PATH_IP = "http://162.252.33.150:8080"
BIG_DATA_PATH_SVC = "NimbusServicesRecent/rest/search/maxdisease"



#UPMIN_PATH = "http://192.168.10.22:3002/admin"
UPMIN_PATH = "http://52.6.96.181:7201/admin"
# RECORD ACTIVE INACTIVE


#BASE_URL = "http://162.242.222.235:5000"
#BASE_URL = "http://localhost:3000"

#MARKETING_BASE_PATH = "localhost:3000"

