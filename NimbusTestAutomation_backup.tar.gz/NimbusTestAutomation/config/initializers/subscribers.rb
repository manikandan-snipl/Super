# TODO ---Subscriber event for Updating the ClientSolutionUser Status -
Subscriber.subscribe('client_sol_user_status.update_status') do |event|

  event_info =  event.payload

 #Mail Notifier needs to be added

end


# Subscriber event for sending mails into Application in all levels, type is the identification for the type of mail, Invite Alert or Status Update etc
Subscriber.subscribe('mailer.trigger_delivery') do |event|

  event_info =  event.payload
  event_type = event_info[:type]

  if event_type == "Invite"
    AdminNotifier.invite(event_info[:user], event_info[:invite], event_info[:license_end_date],event_info[:email_to],event_info[:solution]).deliver
  end

end


# TODO -- As of now feed notification is added to the collection, later below section will be modified and usable based on message types all relevant notifications
Subscriber.subscribe('message.created') do |event|
  error = "Error: #{event.payload[:exception].first}" if event.payload[:exception]
  messages = []
  count = 0
  collection = Message.msg_notification_collection
  feed_owner = event.payload[:user]
  message = event.payload[:message]
  follower_ids = feed_owner.followers_by_client_solution.map(&:id)
  room_name = event.payload[:room_name]
  conversation_type = event.payload[:conversation_type]

  if collection.present?
    p "Subscriber Model -- Message Collection Exists -----------  "
    if (FEEDS_ARRAY.include?(message.message_type.to_s))

      follower_ids && follower_ids.each do  |follower|
        (collection[:feed_notification][:feed_send_rec_collection].present? && collection[:feed_notification][:feed_send_rec_collection].keys.include?("#{feed_owner.id}_#{follower}")) ?  collection[:feed_notification][:feed_send_rec_collection]["#{feed_owner.id}_#{follower}"].push(message.id) : collection[:feed_notification][:feed_send_rec_collection]["#{feed_owner.id}_#{follower}"] = [message.id]

        if (collection[:feed_notification][:messages_data].present? && collection[:feed_notification][:messages_data].keys.include?("#{follower}"))
          collection[:feed_notification][:messages_data]["#{follower}"] << {sender_id: feed_owner.id,unique_id: message.id,follower_ids: follower_ids, feed_content: message.content, full_name: feed_owner.full_name,profile_pic: feed_owner.profile_pic, time: message.created_at, feed_type: message.message_type}
        else
          collection[:feed_notification][:messages_data]["#{follower}"] = [{sender_id: feed_owner.id,unique_id: message.id,follower_ids: follower_ids, feed_content: message.content, full_name: feed_owner.full_name,profile_pic: feed_owner.profile_pic, time: message.created_at, feed_type: message.message_type}]
        end
      end
      Message.msg_notification_collection = collection
    elsif (MESSAGES_ARRAY.include?(message.message_type.to_s))
      p "Subscriber Model -- Message- chat notification --------------"
      group = Cloud::CHAT_MANAGER.check_individual_group(feed_owner,message.messagable_to_group_id,201)
      follower_ids = group.present? ? group.user_ids : []
      follower_ids.delete(feed_owner.id) if follower_ids.present?

      follower_ids && follower_ids.each do  |follower|
        p follower.inspect
        collection[:chat_notification][:msg_send_rec_collection].present? && collection[:chat_notification][:msg_send_rec_collection].keys.include?("#{feed_owner.id}_#{follower}") ?  collection[:chat_notification][:msg_send_rec_collection]["#{feed_owner.id}_#{follower}"].push(message.id) : collection[:chat_notification][:msg_send_rec_collection]["#{feed_owner.id}_#{follower}"] = [message.id]
        if (collection[:chat_notification][:messages_data].present? && collection[:chat_notification][:messages_data].keys.include?("#{follower}"))
          collection[:chat_notification][:messages_data]["#{follower}"] << {room_name: room_name,sender_id: feed_owner.id,unique_id: message.id,follower_ids: follower_ids, feed_content: message.content, full_name: feed_owner.full_name,profile_pic: feed_owner.profile_pic, time: message.created_at, feed_type: message.message_type}
        else
          collection[:chat_notification][:messages_data]["#{follower}"] = [{room_name: room_name,sender_id: feed_owner.id,unique_id: message.id,follower_ids: follower_ids, feed_content: message.content, full_name: feed_owner.full_name,profile_pic: feed_owner.profile_pic, time: message.created_at, feed_type: message.message_type}]
        end
      end
      Message.msg_notification_collection = collection
    end

  else
    p "Subscriber Model -- Information -------------------------- "
    p feed_owner.inspect

    if (FEEDS_ARRAY.include?(message.message_type.to_s))
      collection = {feed_notification: {count: 1, :feed_send_rec_collection => {}, :messages_data => {}}}
      feed_collection = collection[:feed_notification]

      follower_ids && follower_ids.each do |follower|
        feed_collection[:feed_send_rec_collection]["#{feed_owner.id}_#{follower}"] = [message.id]
        feed_collection[:messages_data]["#{follower}"] = [{sender_id: feed_owner.id, unique_id: message.id,follower_ids: follower_ids, feed_content: message.content, full_name: feed_owner.full_name,profile_pic: feed_owner.profile_pic, time: message.created_at, feed_type: message.message_type}]
      end
      Message.msg_notification_collection = collection
    elsif (MESSAGES_ARRAY.include?(message.message_type.to_s))
      p "Subscriber Model -- Message New Collection ----------------------- "
      group = Cloud::CHAT_MANAGER.check_individual_group(feed_owner,message.messagable_to_group_id,201)
      follower_ids = group.present? ? group.user_ids : []
      follower_ids.delete(feed_owner.id) if follower_ids.present?

      collection = {chat_notification: {count: 1, :msg_send_rec_collection => {}, :messages_data => {}}}
      chat_collection = collection[:chat_notification]

      follower_ids && follower_ids.each do |follower|
        chat_collection[:msg_send_rec_collection]["#{feed_owner.id}_#{follower}"] = [message.id]
        chat_collection[:messages_data]["#{follower}"] = [{room_name: room_name, sender_id: feed_owner.id, unique_id: message.id,follower_ids: follower_ids, feed_content: message.content, full_name: feed_owner.full_name,profile_pic: feed_owner.profile_pic, time: message.created_at, feed_type: message.message_type}]
      end
      Message.msg_notification_collection = collection
    end
  end

end