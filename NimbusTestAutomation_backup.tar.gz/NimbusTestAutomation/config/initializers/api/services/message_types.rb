# Message Constants
MESSAGES = "0,2,3,4,5,6"#0-text,1-note,2-image,3-audio,4-video,5-contact,6-location
POSTS = "0,2,3,4,7,8,9,10,11"
NW_FEEDS = "7,8,9,10"
FEEDS = "7,8,9,10,11,12"#7-text,8-image,9-video,10-audio,11-contact,12-location
COMMENT_TYPE = "0,2,3,4,6"#0-text,2-image,3-audio,4-video,6-location
USER_COMMENT_TYPE = "7,8,9,10,11"#7-text,8-image,9-audio,10-video,11-location
ATTACHMENT_MEDIA = "'image','audio','video'"


ONLINE_LIMIT = 20
TOPIC_PROVIDER = 1
DEFAULT_SOLTUION = ' Nimbus'
PER_PAGE = 3