PRINT_LOG = true
ACTIVE_STATUS_CODES=[1,2,3,4,5,6]
INACTIVE_STATUS_CODES=[-1,-2,-3,-4,-5,-6,-7,-8]
STATUS_DESC={:'1'=>'Active', :'-1'=>'Inactive',:'-2'=> 'OnHold',:'-3'=> 'PaymentHold', :'-4'=>'LegalHold',:'-5'=> 'BusinessHold',:'2'=>'DataHold', :'-6'=>'RelationshipHold',:'3'=> 'ResumeIn1Week',:'4'=> 'Resumein1Month',:'5'=> 'Resumein1Quarter',:'6'=> 'Resumein1Yea',:'-7'=>'Suspended',:'-8'=>'Expired'}
