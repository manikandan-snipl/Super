# MEMBER VERIFICATION STATUS
BLOCKED = '-1'
DEFAULT = '0'
VERIFIED = '1'

PLACEHOLDER = "public/place_holder_images"
ACTIVE = 1
INACTIVE = -1
EXPIRED = -8
UNLOCK_REGISTER_NEW_TYPE=0
UNLOCK_REGISTER_NEW = 2
UNLOCK_ADD_NEW_USER_TYPE=1
UNLOCK_ADD_NEW_USER=5
UNLOCK_ADD_NEW_DEVICE_TYPE=2
UNLOCK_ADD_NEW_DEVICE=6
UNLOCK_REMOVE_USER_TYPE=3
UNLOCK_REMOVE_USER=7

INVITE_EMAIL_STATUS=[2,5,6,7] #2 new registration, 5-add user, 6-add device,#7 remove user
ADMIN_TENANT_USER_ID = 1
NIMBUS_ADMIN_STATUS=9999
ADMIN_TENANT_USER_IDS=[1,2,3]
NIMBUS_ADMIN_LICENSE_DESC='Perpetual'


INVITATION_CODE_LIMIT = 20
VERIFIED_INVITATION = 2
CONFIRM_INVITATION = 3
EXPIRED_INVITATION = -1

DEFAULT_SCHEMA='supra_nimbus'
DEFAULT_SOLUTION='nimbus'

LICENSE_STATUS= [["Active", 1], ["Suspended", 2], ["Unused", 3],["Expired", 4]]
USER_STATUS= {"Active" =>  1, "Suspended" => 2,"Deleted" => 3,"Archived" => 4}
GROUP_STATUS= {"Active" =>  1, "Suspended" => 2,"Deleted" => 3,"Archived" => 4}
FACEGURU_VERSIONS=  ["Basic", "Standard", "Professional", "Enterprise", "Premium"]
FACEGURU_VERSION_TYPES=  {"Basic" =>  1, "Standard" => 2,"Professional" => 3,"Enterprise" => 4,"Premium" => 5}
INVITATION_STATUS = {"1" => "ACTIVE", "2" => "VERIFIED", "3" => "CONFIRMED", "-1" =>"EXPIRED",  "0" => "IMPORTED"}