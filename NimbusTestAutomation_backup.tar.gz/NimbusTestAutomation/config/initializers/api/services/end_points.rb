require 'api_config'

ApiConfig.config = YAML.load_file("config/initializers/api/services/end_points.yml")[Rails.env].symbolize_keys