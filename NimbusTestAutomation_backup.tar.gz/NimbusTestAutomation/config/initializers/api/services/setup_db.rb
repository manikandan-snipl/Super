
EXCHANGE_SCHEMA = "exchange"
GATEWAY_SCHEMA = "gateway"
BUNDLE_VERSION_SEPARATOR = "#bundle-version#"
SKIP_LICENSE_CHECK_FOR_APPS=['facedox']
SHARED_TABLES = ['clients','solutions','client_solutions','client_solutions_users']
CONSUMER_APPS = ['facedox']
TENANTS=['exchange', 'facedox', 'supra_nimbus', 'k7_pharma', 'cibola_resorts', 'narada_media', 'lakme_financial', '7hills_hospital',
         'jims_hospital', 'danvanthree_pharma', 'wyaz_pharma','ursamajor_pharma', 'mayan_constructions', 'andromeda_pharma', 'atlantis_development',
         'lemuria_development', 'dwarka_testing', '7pagoda_testing', 'viraja_staging', 'mocha_staging', 'cignet_development', 'ariana_development', 'giza_pharma',
         'babylon_pharma', 'olympia_pharma', 'ephesus_pharma', 'halio_engineering', 'rhodes_media', 'alexa_travels']

TENANT_SCHEMA='tenant'
CLIENT_CSV = "public/03-Clients.csv"
SOLUTION_CSV = "public/02-Solutions.csv"
CLIENT_SOLUTION_CSV = "public/04-ClientSolutions.csv"
CLIENT_SOLUTIONS_USER_CSV = "public/05-ClientSolutionUsers.csv"
CLIENT_MODAL = "Client"
SOLUTION_MODAL = "Solution"
CLIENT_SOLUTION_MODAL = "ClientSolution"
CLIENT_SOLUTIONS_USER_MODAL = "ClientSolutionsUser"
USER_MODAL='User'
USER_CSV='public/01-User.csv'
INVITE_MODAL = "Invite"
TENANTS_SCHEMAS=['supra_nimbus', 'k7_pharma', 'cibola_resorts', 'narada_media', 'lakme_financial', '7hills_hospital', 'jims_hospital', 'danvanthree_pharma', 'wyaz_pharma','ursamajor_pharma', 'mayan_constructions', 'andromeda_pharma', 'atlantis_development', 'lemuria_development', 'dwarka_testing', '7pagoda_testing', 'viraja_staging', 'mocha_staging', 'cignet_development', 'ariana_development', 'giza_pharma', 'babylon_pharma', 'olympia_pharma', 'ephesus_pharma', 'halio_engineering', 'rhodes_media', 'alexa_travels']

INVITES_CSV_SEEDS={:"ursamajor_pharma"=>"06-10-UrsaMajor-Invites.csv",:"cibola_resorts"=>"06-03-Cibola-Invites.csv",
                   :"7pagoda_testing"=>"06-16-7Pagodas-Invites.csv",:"lakme_financial"=>"06-05-Lakme-Invites.csv",
                   :"dwarka_testing"=>"06-15-Dwarka-Invites.csv",:"7hills_hospital"=>"06-06-7Hills-Invites.csv",
                   :"danvanthree_pharma"=>"06-08-DanvanThree-Invites.csv",
                   :"andromeda_pharma"=>"06-12-Andromeda-Invites.csv",:"mocha_staging"=>"06-18-Mocha-Invites.csv",
                   :"lemuria_development"=>"06-14-Lemuria-Invites.csv",:"atlantis_development"=>"06-13-Atlantis-Invites.csv",
                   :"giza_pharma"=>"06-21-Giza-Invites.csv",:"supra_nimbus"=>"06-01-Supra-Invites.csv",:"babylon_pharma"=>"06-22-Babylon-Invites.csv",
                   :"halio_engineering"=>"06-25-Halio-Invites.csv",:"narada_media"=>"06-04-Narada-Invites.csv",:"wyaz_pharma"=>"06-09-Wyaz-Invites.csv",
                   :"rhodes_media"=>"06-26-Rhodes-Invites.csv",:"ariana_development"=>"06-20-Ariana-Invites.csv",:"jims_hospital"=>"06-07-Jims-Invites.csv",:"alexa_travels"=>"06-27-Alexa-Invites.csv",
                   :"mayan_constructions"=>"06-11-Mayan-Invites.csv",:"ephesus_pharma"=>"06-24-Ephesus-Invites.csv",:"viraja_staging"=>"06-17-Viraja-Invites.csv",:"cignet_development"=>"06-19-Cignet-Invites.csv",
                   :"olympia_pharma"=>"06-23-Olympia-Invites.csv",:"k7_pharma"=>"06-02-K7-Invites.csv"}


ENGINES_TO_COPY_MIGRATIONS = [  'fat_free_crm_engine',   'common_engine'  ]
