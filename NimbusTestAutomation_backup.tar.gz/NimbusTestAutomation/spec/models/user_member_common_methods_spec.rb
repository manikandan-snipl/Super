require 'rails_helper'
require "#{Rails.root}/spec/shared/models/user_member_shared_exampless.rb"

RSpec.describe UserMemberCommonMethods, type: :model do

  it "has a valid user factory" do
    expect(build(:user)).to be_valid
  end

  it "has a valid member factory" do
    expect(build(:member)).to be_valid
  end

  describe "public class methods" do
    before (:each) do
      @user = create(:user)
      @member = create(:member)
      @client = create(:client, user_id: @user.id)
      @solution = create(:solution)
      @client_solution = create(:client_solution, client_id: @client.id,solution_id: @solution.id, license_max_limit:'100')
      @client_solutions_user = create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id )
    end

    context "User Model responds to its methods" do
      it { expect(User).to respond_to(:friend_ids) }
      it { expect(User).to respond_to(:friend_ids_array) }
    end

    context "execute methods correctly" do
      context "self.friend_ids" do
        context " when followers and followings are not present for the current_user as (New User) User" do
          subject(:following_ids)  {@user.followers.collect(&:id)}
          subject(:followers_ids)  {@user.all_following.reject{|c| c.class_name != 'User'}.collect(&:id)}

          it "returns the following_ids data as empty array of the current user" do
            expect(following_ids).to match_array([])
            expect(following_ids).to be_empty
          end

          it "returns the followers data as empty array of the current user" do
            expect(followers_ids).to match_array([])
            expect(followers_ids).to be_empty
          end

          it "returns only current user id" do
            result = User.friend_ids("User",@user)
            expect(result).to be_a(Fixnum)
            expect(result).to eq(@user.id)
          end
        end

        context " when followers and followings are not present for the current_user as (New Member) Member" do

          it "returns the followers and followings data as empty array of the Member" do
            expect(@member.followers_row).to match_array([])
            expect(@member.followers_row).to be_empty
            expect(@member.followings_row).to match_array([])
            expect(@member.followings_row).to be_empty
          end

          it "returns only current user(Member) id" do
            result = User.friend_ids("Member",@member)
            expect(result).to be_a(Fixnum)
            expect(result).to eq(@member.id)
          end

        end

        context "when Current User(User) following @user2 and current user is followed by @user1" do
          before (:each) do
            @user1 = create(:user)
            @user2 = create(:user)
            @follower = create(:follow, followable_id: @user.id, follower_id: @user1.id,member_id: @user1.id )
            @following = create(:follow, followable_id: @user2.id, follower_id: @user.id,member_id: @user.id)
          end

          subject(:following_ids)  {@user.all_following.reject{|c| c.class_name != 'User'}.collect(&:id)}
          subject(:followers_ids)  {@user.followers.collect(&:id)}

          it "returns the following_ids data as array of of @user2" do
            expect(following_ids).to match_array([@user2.id])
            expect(following_ids).not_to be_empty
          end

          it "returns the followers data as empty array of the @user1" do
            expect(followers_ids).to match_array([@user1.id])
            expect(followers_ids).not_to be_empty
          end

          it "returns the follower and following ids with current user_id as a string is @user2,@user1,current_user ids" do
            result = User.friend_ids("User",@user)
            expect(result).to be_a(String)
            friend_ids = following_ids+followers_ids.push(@user.id)
            expect(result).to eq(friend_ids.join(","))
          end
        end
      end

      context "self.friend_ids_array" do
        context " when followers and followings are not present for the current_user (New User)" do
          subject(:following_ids)  {@user.followers.collect(&:id)}
          subject(:followers_ids)  {@user.all_following.reject{|c| c.class_name != 'User'}.collect(&:id)}

          it "returns the following_ids data as empty array of the current user" do
            expect(following_ids).to match_array([])
            expect(following_ids).to be_empty
          end

          it "returns the followers data as empty array of the current user" do
            expect(followers_ids).to match_array([])
            expect(followers_ids).to be_empty
          end

          it "returns an array contains only current user id" do
            result = User.friend_ids_array("web_user",@user)
            expect(result).to be_a(Array)
            expect(result).to match_array([@user.id])
          end
        end

        context "when Current User following @user2 and current user is followed by @user1" do
          before (:each) do
            @user1 = create(:user)
            @user2 = create(:user)
            @follower = create(:follow, followable_id: @user.id, follower_id: @user1.id,member_id: @user1.id )
            @following = create(:follow, followable_id: @user2.id, follower_id: @user.id,member_id: @user.id)
          end

          subject(:following_ids)  {@user.all_following.reject{|c| c.class_name != 'User'}.collect(&:id)}
          subject(:followers_ids)  {@user.followers.collect(&:id)}

          it "returns the following_ids data as array of of @user2" do
            expect(following_ids).to match_array([@user2.id])
            expect(following_ids).not_to be_empty
          end

          it "returns the followers data as empty array of the @user1" do
            expect(followers_ids).to match_array([@user1.id])
            expect(followers_ids).not_to be_empty
          end

          it "returns the follower and following ids with current user_id as a array is @user2,@user1,current_user ids" do
            result = User.friend_ids_array("web_user",@user)
            expect(result).to be_a(Array)
            friend_ids = [@user.id]+following_ids+followers_ids
            expect(result).to eq(friend_ids)
          end
        end
    end
    end
  end

  describe "instance methods" do

    before (:each) do
      @user = create(:user)
      @member = create(:member)
      @client = create(:client, user_id: @user.id)
      @solution = create(:solution)
      @client_solution = create(:client_solution, client_id: @client.id,solution_id: @solution.id, license_max_limit:'100')
      @client_solutions_user = create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id,user_license_code: @user.invite_code )
    end

    context "User Instance should responds to its methods" do
      it { expect(@user).to respond_to(:follower_ids) }
      it { expect(@user).to respond_to(:following_ids) }
      it { expect(@user).to respond_to(:member_address) }
      it { expect(@user).to respond_to(:member_following) }
      it { expect(@user).to respond_to(:member_followers) }
      it { expect(@user).to respond_to(:member_info) }
      it { expect(@user).to respond_to(:member_short_info) }
      it { expect(@user).to respond_to(:full_name) }
    end

    context "execute method's correctly" do
      let(:user) {@user}
      let(:member) {@member}

      context "#follower_ids" do
        it_behaves_like "an empty follower_ids array"
        it_behaves_like "follower_ids array"
      end

      context "#following_ids" do
        it_behaves_like "it returns following_ids array as empty"
        it_behaves_like "it returns following_ids array"
      end

      context "#member_short_info" do
        it_behaves_like "it returns member_short_info as a array"
        it_behaves_like "member_short_info with failures"
      end

      context "#member_info" do
        it_behaves_like "it returns member_information's"
        it_behaves_like "member_info method with failures"
      end

      context "#member_following" do
        it_behaves_like "execute member_following method properly"
        it_behaves_like "execute member_following method with failures"
      end

      context "#member_followers" do
        it_behaves_like "execute member_followers method properly"
        it_behaves_like "execute member_following method with failures"
      end

      context "#full_name" do
        context "when calling full_name as  User instance" do
          let(:entity) {user}
          let(:entity_type) {'User'}
          it_behaves_like "returns full name of the given User"
        end

        context "when calling full_name as  Member instance" do
          let(:entity) {member}
          let(:entity_type) {'Member'}
          it_behaves_like "returns full name of the given User"
        end
      end

      context "#member_address" do
        context "when calling member_address as  User instance" do
          let(:entity) {user}
          let(:entity_type) {'User'}
          it_behaves_like "returns full name of the given User"
        end

        context "when calling member_address as  Member instance" do
          let(:entity) {member}
          let(:entity_type) {'Member'}
          it_behaves_like "returns full name of the given User"
        end
      end

    end
  end
end

