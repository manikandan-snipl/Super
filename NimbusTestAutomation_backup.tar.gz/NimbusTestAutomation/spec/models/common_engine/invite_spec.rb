require 'rails_helper'

module CommonEngine
  RSpec.describe Invite, type: :model do
  let(:invite) { build(:invite) }

  it "has a valid factory" do
    expect(invite).to be_valid
  end

  describe "ActiveModel validations" do

    # Basic validations
    #  it { expect(invite).to validate_uniqueness_of(:invite_code).with_message("already taken") }
    it { expect(invite).to validate_presence_of(:from_id) }
    it { expect(invite).to validate_presence_of(:from_type) }
    it { expect(invite).to validate_presence_of(:email_from) }
    it { expect(invite).to validate_presence_of(:first_name) }
    it { expect(invite).to validate_presence_of(:last_name) }
    it { expect(invite).to validate_presence_of(:email_to) }
    it { expect(invite).to validate_uniqueness_of(:email_to).with_message("already taken") }
    it { expect(invite).to validate_presence_of(:phone_number) }
    it { expect(invite).to validate_uniqueness_of(:phone_number).with_message("already taken") }

    it "is invalid without a from_id" do
      record = build(:invite, from_id: nil)
      expect(record).to_not be_valid
      expect(record.errors[:from_id]).to include("can't be blank")
    end

    it "is invalid without a from_type" do
      record = build(:invite, from_type: nil)
      expect(record).to_not be_valid
      expect(record.errors[:from_type]).to include("can't be blank")
    end

    it "is invalid without a email_from" do
      record = build(:invite, email_from: nil)
      expect(record).to_not be_valid
      expect(record.errors[:email_from]).to include("can't be blank")
    end

    it "is invalid without a first_name" do
      record = build(:invite, first_name: nil)
      expect(record).to_not be_valid
      expect(record.errors[:first_name]).to include("can't be blank")
    end

    it "is invalid without a last_name" do
      record = build(:invite, last_name: nil)
      expect(record).to_not be_valid
      expect(record.errors[:last_name]).to include("can't be blank")
    end

    it "is invalid without a email_to" do
      record = build(:invite, email_to: nil)
      expect(record).to_not be_valid
      expect(record.errors[:email_to]).to include("can't be blank")
    end

    it "is invalid without a phone_number" do
      record = build(:invite, phone_number: nil)
      expect(record).to_not be_valid
      expect(record.errors[:phone_number]).to include("can't be blank")
    end

    it "is invalid and raises an error invite_code is already present" do
      record1 = create(:invite, invite_code: "MSP")
      record2 = build(:invite, invite_code: "MSP")
      expect(record2).to_not be_valid
      expect(record2.errors[:invite_code]).to include("already taken")
    end

    it "is invalid and raises an error phone_number is already present" do
      record1 = create(:invite, phone_number: "123456")
      record2 = build(:invite, phone_number: "123456")
      expect(record2).to_not be_valid
      expect(record2.errors[:phone_number]).to include("already taken")
    end

    it "is invalid and raises an error email_to is already present" do
      record1 = create(:invite, email_to: "krishna@gmail.com")
      record2 = build(:invite, email_to: "krishna@gmail.com")
      expect(record2).to_not be_valid
      expect(record2.errors[:email_to]).to include("already taken")
    end


    it "is invalid email_from is not a valid email" do
      expect(build(:invite, email_from: "user@foo,com")).to_not be_valid
      expect(build(:invite, email_from: "user_at_foo.org")).to_not be_valid
      expect(build(:invite, email_from: "example.user@foo.")).to_not be_valid
      expect(build(:invite, email_from: "foo@bar_baz.com")).to_not be_valid
      expect(build(:invite, email_from: "foo@bar+baz.com")).to_not be_valid
    end

    it "is invalid email_to is not a valid email" do
      expect(build(:invite, email_to: "user@foo,com")).to_not be_valid
      expect(build(:invite, email_to: "user_at_foo.org")).to_not be_valid
      expect(build(:invite, email_to: "example.user@foo.")).to_not be_valid
      expect(build(:invite, email_to: "foo@bar_baz.com")).to_not be_valid
      expect(build(:invite, email_to: "foo@bar+baz.com")).to_not be_valid
    end

  end

  describe "ActiveRecord associations" do

    # Associations
    it { expect(invite).to belong_to(:contact) }

  end

  context "callbacks" do
    let(:invite) { create(:invite)}
    it { is_expected.to callback(:validate_save_and_create_csoluser).before(:create) }
    it { is_expected.to callback(:send_invite).after(:create) }
  end

  describe "scopes" do
    context "#by_contact" do
      before (:each) do
        @user = FactoryGirl.create(:user)
        @client = FactoryGirl.create(:client, user_id: @user.id)
        @solution = FactoryGirl.create(:solution)
        @client_solution = FactoryGirl.create(:client_solution, client_id: @client.id,solution_id: @solution.id)
        @client_solutions_user = FactoryGirl.create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id )
      end

      context "execute scope method with success" do

        let(:invite1) { FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email) }
        let(:invite2) { FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email) }
        let(:invites) { [invite1, invite2] }
        let(:users){ invites.map{|invite| FactoryGirl.create(:user, first_name: invite.first_name, last_name: invite.last_name, email: invite.email_to, invite_code: invite.invite_code)}}

        it "returns all invites sent by current user" do
          expect(Invite.by_contact(@user)).to eq(invites)
        end

        it "returns nil If there is no invites sent by current user" do
          expect(Invite.by_contact(@user)).to eq([])
        end
      end

      context "execute scope method with failure" do
        it "should raise an ArgumentError error if no parameters passed" do
          expect {Invite.by_contact}.to raise_error(ArgumentError)
        end

        it "should raise an ArgumentError error if more than one parameters passed" do
          expect {Invite.by_contact("","")}.to raise_error(ArgumentError)
        end

        it "should raise an error If argument is passing as empty string" do
          expect {Invite.by_contact("")}.to raise_error(NoMethodError)
        end

      end
    end

    context "#by_status" do
      let(:invite1) { FactoryGirl.create(:invite, status: CONFIRM_INVITATION) }
      let(:invite2) { FactoryGirl.create(:invite, status: CONFIRM_INVITATION) }
      let(:invites) { [invite1, invite2] }

      it "returns all invites which is confirmed by the users" do
        expect(Invite.by_status).to eq(invites)
      end

      it "returns empty array If there is no invites confirmed by users" do
        expect(Invite.by_status).to eq([])
      end
    end
  end

end
end