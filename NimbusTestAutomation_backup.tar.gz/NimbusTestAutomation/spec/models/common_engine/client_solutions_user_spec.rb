require 'rails_helper'

module CommonEngine
  RSpec.describe CommonEngine::ClientSolutionsUser, type: :model do

  let(:client_solutions_user) { build(:client_solutions_user) }

  it "has a valid factory" do
    expect(build(:client_solutions_user)).to be_valid
  end

  describe "ActiveModel validations" do

    # Basic validations
    it { expect(client_solutions_user).to validate_uniqueness_of(:user_license_code).with_message("already taken") }
    it { expect(client_solutions_user).to validate_presence_of(:user_license_code).with_message("should present") }
    it { expect(client_solutions_user).to validate_presence_of(:user_license_type).with_message("should present") }

    # Format validations
    it { expect(client_solutions_user).to allow_value("").for(:license_start_date) }
    it { expect(client_solutions_user).to allow_value("").for(:license_end_date) }


    it "is invalid without a user_license_type" do
      record = build(:client_solutions_user, user_license_type: nil)
      expect(record).to_not be_valid
      expect(record.errors[:user_license_type]).to include("should present")
    end

    it "is invalid and raises an error user_license_code is already present" do
      record1 = create(:client_solutions_user, user_license_code: "MSP")
      record2 = build(:client_solutions_user, user_license_code: "MSP")
      expect(record2).to_not be_valid
      expect(record2.errors[:user_license_code]).to include("already taken")
    end

    it "is invalid without a user_license_code" do
      record = build(:client_solutions_user, user_license_code: nil)
      expect(record).to_not be_valid
      expect(record.errors[:user_license_code]).to include("should present")
    end

    it "is allows license_start_date as blank" do
      record = build(:client_solutions_user, license_start_date: "")
      expect(record).to be_valid
    end

    it "is allows license_end_date as blank" do
      record = build(:client_solutions_user, license_end_date: "")
      expect(record).to be_valid
    end
  end

  describe "ActiveRecord associations" do

    # Associations
    it { expect(client_solutions_user).to belong_to(:client_solution) }
    it { expect(client_solutions_user).to belong_to(:user) }

  end

  context "callbacks" do
    let(:client_solutions_user) { create(:client_solutions_user) }
    it { is_expected.to callback(:timestamp).before(:create) }

    context "#client_solution_user_expiration_date_cannot_be_in_the_past" do

      context "when license_end_date is lesser than today date " do
        subject(:client_sol_user_data) {build(:client_solutions_user, license_start_date: Date.today-10.days, license_end_date: Date.today+1)}

        it 'should raise error' do
          client_sol_user_data.license_end_date = Date.today-10.days
          client_sol_user_data.send :client_solution_user_expiration_date_cannot_be_in_the_past
          expect(client_sol_user_data.errors[:license_end_date]).to_not be_nil
          expect(client_sol_user_data.errors[:license_end_date]).to include( I18n.t("ERROR_CODES.CLIENT.CLS_EXPIRY_002"))
        end
      end

      context "when license_end_date is greater than today date " do
        subject(:client_sol_user_data) {build(:client_solutions_user, license_start_date: Date.today-10.days, license_end_date: Date.today+1)}

        it 'should not raise error' do
          client_sol_user_data.license_end_date = Date.today
          client_sol_user_data.send :client_solution_user_expiration_date_cannot_be_in_the_past
          expect(client_sol_user_data.errors[:license_end_date]).to match_array([])
          expect(client_sol_user_data.errors[:license_end_date]).not_to include( I18n.t("ERROR_CODES.CLIENT.CLS_EXPIRY_002"))
        end
      end
    end

    context "execute before_save timestamp method" do
      it "assings the license_start_date and license_end_date" do
        client_sol_user = build(:client_solutions_user)
        expect(client_sol_user.license_start_date).to be_nil
        expect(client_sol_user.license_end_date).to be_nil
        client_sol_user.save
        expect(client_sol_user.license_start_date).not_to be_nil
        expect(client_sol_user.license_end_date).not_to be_nil
      end
    end
  end

end
end