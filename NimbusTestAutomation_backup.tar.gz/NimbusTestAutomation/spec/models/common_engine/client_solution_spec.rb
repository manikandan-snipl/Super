require 'rails_helper'

module CommonEngine
  RSpec.describe ClientSolution, type: :model do

  let(:client_solution) { build(:client_solution) }

  it "has a valid factory" do
    expect(build(:client_solution)).to be_valid
  end

  describe "ActiveModel validations" do

    # Basic validations
    it { expect(client_solution).to validate_presence_of(:license_max_limit).with_message("specify license limit") }
    it { expect(client_solution).to validate_presence_of(:solution_license_code).with_message("should present") }
    it { expect(client_solution).to validate_presence_of(:solution_license_type).with_message("should present") }

    # Format validations
    it { expect(client_solution).to allow_value("").for(:license_start_date) }
    it { expect(client_solution).to allow_value("").for(:license_end_date) }

    it "is invalid without a license_max_limit" do
      record = build(:client_solution, license_max_limit: nil)
      expect(record).to_not be_valid
      expect(record.errors[:license_max_limit]).to include("specify license limit")
    end

    it "is invalid without a solution_license_code" do
      record = build(:client_solution, solution_license_code: nil)
      expect(record).to_not be_valid
      expect(record.errors[:solution_license_code]).to include("should present")
    end

    it "is invalid without a solution_license_type" do
      record = build(:client_solution, solution_license_type: nil)
      expect(record).to_not be_valid
      expect(record.errors[:solution_license_type]).to include("should present")
    end

    it "is allows license_start_date as blank" do
      record = build(:client_solution, license_start_date: "")
      expect(record).to be_valid
    end

    it "is allows license_end_date as blank" do
      record = build(:client_solution, license_end_date: "")
      expect(record).to be_valid
    end

  end

  describe "ActiveRecord associations" do

    # Associations
    it { expect(client_solution).to belong_to(:client) }
    it { expect(client_solution).to belong_to(:solution) }
    it { expect(client_solution).to have_many(:client_solutions_users) }
  end

  context "callbacks" do
    let(:client_solution) { create(:client_solution) }
    it { is_expected.to callback(:timestamp).before(:save) }

    context "#client_solution_expiration_date_cannot_be_in_the_past" do

      context "when license_end_date is lesser than today date " do
        subject(:client_solution_data) {build(:client_solution, license_max_limit:'100', license_start_date: Date.today-10.days, license_end_date: Date.today)}

        it 'should raise error' do
          client_solution_data.license_end_date = Date.today-10.days
          client_solution_data.send :client_solution_expiration_date_cannot_be_in_the_past
          expect(client_solution_data.errors[:license_end_date]).to_not be_nil
          expect(client_solution_data.errors[:license_end_date]).to include( I18n.t("ERROR_CODES.CLIENT.CLS_EXPIRY_002"))
        end
      end

      context "when license_end_date is greater than today date " do
        subject(:client_solution_data) {build(:client_solution, license_max_limit:'100', license_start_date: Date.today-10.days, license_end_date: Date.today)}

        it 'should not raise error' do
          client_solution_data.license_end_date = Date.today
          client_solution_data.send :client_solution_expiration_date_cannot_be_in_the_past
          expect(client_solution_data.errors[:license_end_date]).to match_array([])
          expect(client_solution_data.errors[:license_end_date]).not_to include( I18n.t("ERROR_CODES.CLIENT.CLS_EXPIRY_002"))
        end
      end
    end

    context "execute before_save timestamp method" do
      it "assings the license_start_date and license_end_date" do
        client_solution = build(:client_solution, license_start_date: nil, license_end_date: nil)
        expect(client_solution.license_start_date).to be_nil
        expect(client_solution.license_end_date).to be_nil
        client_solution.save
        expect(client_solution.license_start_date).not_to be_nil
        expect(client_solution.license_end_date).not_to be_nil
      end
    end
  end

end
end