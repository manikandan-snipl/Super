#require 'rails_helper'
#
#module CommonEngine
#  RSpec.describe User, type: :model do
#  it { should have_many(:group_chats).through(:group_users) }
#  end
#end


require 'rails_helper'
RSpec.describe User, type: :model do
# it { should validate_presence_of :name }
# it { expect(profile_information).to validate_presence_of(:name) }
it "is valid with valid attributes" do
  expect(User.new(firstname: 'Anything')).to be_valid
end

end