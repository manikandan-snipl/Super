require 'rails_helper'

module CommonEngine
  RSpec.describe Solution, type: :model do

  it "has a valid factory" do
    expect(build(:solution)).to be_valid
  end

  let(:solution) { build(:solution) }

  describe "ActiveModel validations" do
    # Basic validations
    it { expect(solution).to validate_presence_of(:package_type).with_message("specify license limit") }
    it { expect(solution).to validate_presence_of(:name).with_message("should present") }
    it { expect(solution).to validate_presence_of(:license_type).with_message("should present") }

    # Format validations
    it { expect(solution).to allow_value("").for(:price) }
  end

  describe "ActiveRecord associations" do
    # Associations
    it { expect(solution).to have_many(:client_solutions) }
    # it { expect(solution).to have_many(:clients) }
    #it { expect(solution).to have_many(:solutions).through(:clients) }
  end

end
end