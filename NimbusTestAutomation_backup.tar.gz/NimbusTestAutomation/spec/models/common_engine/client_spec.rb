require 'rails_helper'

module CommonEngine
  RSpec.describe Client, type: :model do
  let(:client) { build(:client) }

  it "has a valid factory" do
    expect(build(:client)).to be_valid
  end

  describe "ActiveModel validations" do

    # Basic validations
    it { expect(client).to validate_uniqueness_of(:master_license_code).with_message("already taken") }
    it { expect(client).to validate_presence_of(:master_license_code).with_message("should present") }
    it { expect(client).to validate_presence_of(:schema_name).with_message("should present") }
    it { expect(client).to validate_presence_of(:legal_name).with_message("should present") }

    # Format validations
    it { expect(client).to allow_value("").for(:license_start_date) }
    it { expect(client).to allow_value("").for(:license_end_date) }

    it "is invalid without a master_license_code" do
      record = build(:client, master_license_code: nil)
      expect(record).to_not be_valid
      expect(record.errors[:master_license_code]).to include("should present")
    end

    it "is invalid and raises an error master_license_code is already present" do
      record1 = create(:client, master_license_code: "MSP")
      record2 = build(:client, master_license_code: "MSP")
      expect(record2).to_not be_valid
      expect(record2.errors[:master_license_code]).to include("already taken")
    end

    it "is invalid without a schema_name" do
      record = build(:client, schema_name: nil)
      expect(record).to_not be_valid
      expect(record.errors[:schema_name]).to include("should present")
    end

    it "is invalid without a legal_name" do
      record = build(:client, legal_name: nil)
      expect(record).to_not be_valid
      expect(record.errors[:legal_name]).to include("should present")
    end

    it "is allows license_start_date as blank" do
      record = build(:client, license_start_date: "")
      expect(record).to be_valid
    end

    it "is allows license_end_date as blank" do
      record = build(:client, license_end_date: "")
      expect(record).to be_valid
    end
  end

  describe "ActiveRecord associations" do
    # Associations
    it { expect(client).to belong_to(:user) }
    it { expect(client).to have_many(:client_solutions) }
    it { expect(client).to have_many(:solutions).through(:client_solutions) }
  end

  context "callbacks" do
    let(:client) { create(:client) }
    it { is_expected.to callback(:timestamp).before(:save) }

    context "execute before_save timestamp method" do
      it "assings the license_start_date and license_end_date" do
        client = build(:client)
        expect(client.license_start_date).to be_nil
        expect(client.license_end_date).to be_nil
        client.save
        expect(client.license_start_date).not_to be_nil
        expect(client.license_end_date).not_to be_nil
      end
    end
  end

  describe "public class methods" do
    before (:each) do
      @user = create(:user)
      @client = create(:client, user_id: @user.id)
      @solution = create(:solution)
      @client_solution = create(:client_solution, client_id: @client.id,solution_id: @solution.id, license_max_limit:'100')
      @client_solutions_user = create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id )
    end

    context "responds to its methods" do
      it { expect(Client).to respond_to(:get_license_count) }
    end

    context "executes methods correctly" do

      context "self.get_license_count" do

        it "returns nil if the client solution record is not present for the current user" do
          ClientSolutionsUser.destroy_all
          expect(Client.get_license_count(@user)).to be_nil
        end

        it "returns client solution user client_solution_id of the current_user if exists" do
          expect(@client_solutions_user).to respond_to(:client_solution_id)
          client_solution_id =  @client_solutions_user.try(:client_solution_id)
          expect(client_solution_id).to eq(@client_solution.id)
        end

        it "stubbed the return value of license maximum limit for the client solution user" do
          allow(Client).to receive(:get_license_count).with(@user).and_return(@client_solution.license_max_limit)
          expect(Client.get_license_count(@user)).to eq(@client_solution.license_max_limit)
          expect(Client).to have_received(:get_license_count)
        end

        it "returns the license maximum limit for the client solution user" do
          expect(Client.get_license_count(@user)).to eq(@client_solution.license_max_limit)
        end

        context "self.get_license_count with failures" do
          it "should raise an ArgumentError error if no parameters passed" do
            expect {Client.get_license_count}.to raise_error(ArgumentError)
          end

          it "should raise an ArgumentError error if more than one parameters passed" do
            expect {Client.get_license_count("","")}.to raise_error(ArgumentError)
          end

          it "should raise an NoMethodError error with undefined method `id' for "":String -- if first argument as empty" do
            expect {Client.get_license_count("")}.to raise_error(NoMethodError)
          end
        end
      end

    end
  end

end
end

