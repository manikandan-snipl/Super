RSpec.shared_examples "get_admin_users" do

  context "when users were present" do

    subject(:invite1) { FactoryGirl.create(:invite, from_id: user.id, email_from: user.email) }
    subject(:invite2) { FactoryGirl.create(:invite, from_id: user.id, email_from: user.email) }
    #subject(:invites) { [invite1, invite2] }
    subject(:invites) { [invite1] }
    subject(:solution_users){ [invite1,invite2].map{|record| FactoryGirl.create(:client_solutions_user, user_id: 0, client_solution_id: client_solution.id,user_license_code: record.invite_code)}}
    subject(:users){ [invite1].map{|invite| FactoryGirl.create(:user, first_name: invite.first_name, last_name: invite.last_name, email: invite.email_to, invite_code: invite.invite_code)}}
    subject(:user2){ [invite2].map{|invite| FactoryGirl.create(:user, first_name: invite.first_name, last_name: invite.last_name, email: invite.email_to, invite_code: invite.invite_code)}}

    subject(:solution_user_ids){ Cloud::CLIENT.get_solution_user_ids(user)}

    it "has to fetch all user ids of current user parent level solution like FaceGuru" do
      get :index
      p users.inspect
      p "$"*66
      p "$"*66
      user_array = users
      expect(solution_user_ids).to be_a(Array)
      #expect(solution_user_ids).to match_array(user_array.map(&:id))
      #expect(solution_user_ids).not_to be_empty
      #expect(solution_user_ids.length).to eq(user_array.length)
    end

    #it "should retrieve admin users based on solution_user_ids with active users" do
    #  user_array = users
    #  get :index
    #  data = Cloud::UserManager.get_user_accepted_invites(user, true,solution_user_ids)
    #  #expect(assigns(:data_set)).not_to be_a(Array)
    #  #expect(assigns(:data_set)).to be_a(ActiveRecord::Relation)
    #  #expect(assigns(:data_set)).to have(user_array.length).items
    #  #expect(assigns(:data_set)).to eq(data)
    #  #expect(assigns(:data_set).to_a).to match_array(user_array)
    #end

    #it "should assign the results to the view page with pagination data" do
    #  user_array = users
    #  get :index
    #  data = Cloud::UserManager.get_user_accepted_invites(user, true,solution_user_ids)
    #  expect(assigns(:results)).to eq(data.page(1).per(PER_PAGE))
    #  expect(assigns(:results)).not_to be_a(Array)
    #  expect(assigns(:results)).to be_a(ActiveRecord::Relation)
    #  expect(assigns(:results)).to have(data.page(1).per(PER_PAGE).length).items
    #end
  end

  ##context "when users were not present" do
  ##  subject(:solution_user_ids){ Cloud::CLIENT.get_solution_user_ids(user)}
  ##
  ##  it "returns no matched user ids of current user parent level solution like FaceGuru" do
  ##    get :index
  ##    expect(solution_user_ids).to be_a(Array)
  ##    expect(solution_user_ids).to match_array([])
  ##    expect(solution_user_ids).to be_empty
  ##    expect(solution_user_ids.length).to eq(0)
  ##  end
  ##
  ##  it "returns empty collection of users based on solution_user_ids with active users" do
  ##    get :index
  ##    data = Cloud::UserManager.get_user_accepted_invites(user, true,solution_user_ids)
  ##    expect(assigns(:data_set)).not_to be_a(Array)
  ##    expect(assigns(:data_set)).to be_a(ActiveRecord::Relation)
  ##    expect(assigns(:data_set)).to have(0).items
  ##    expect(assigns(:data_set)).to eq(data)
  ##    expect(assigns(:data_set).to_a).to match_array([])
  ##  end
  ##
  ##  it "should assign the results as empty to the view page with pagination data" do
  ##    #user_array = users
  ##    get :index
  ##    data = Cloud::UserManager.get_user_accepted_invites(user, true,solution_user_ids)
  ##    expect(assigns(:results)).to eq(data.page(1).per(PER_PAGE))
  ##    expect(assigns(:results)).not_to be_a(Array)
  ##    expect(assigns(:results)).to be_a(ActiveRecord::Relation)
  ##    expect(assigns(:results)).to have(data.page(1).per(PER_PAGE).length).items
  ##  end
  #
  #end
end

RSpec.shared_examples "get_admin_users with failures" do

  it "should raise an Failure/Error executes get_solution_user_ids if invalid parameters passed" do
    expect {Cloud::CLIENT.get_solution_user_ids("")}.to raise_error(NoMethodError, /undefined method `invite_code' for "":String/)
  end

  it "should raise an ArgumentError executes get_solution_user_ids  with no parameters passed" do
    expect {Cloud::CLIENT.get_solution_user_ids()}.to raise_error(ArgumentError, "wrong number of arguments (0 for 1)")
  end

  it "should raise an ArgumentError executes get_solution_user_ids  if more than one parameters passed" do
    expect {Cloud::CLIENT.get_solution_user_ids("", "")}.to raise_error(ArgumentError, "wrong number of arguments (2 for 1)")
  end

  it "should raise an Failure/Error executes get_user_accepted_invites if first parameter as invalid string" do
    expect {Cloud::UserManager.get_user_accepted_invites("", true,[])}.to raise_error(NoMethodError, /undefined method `invite_code' for "":String/)
  end

  it "should raise an Failure/Error executes get_user_accepted_invites if first parameter as invalid string" do
    expect {Cloud::UserManager.get_user_accepted_invites(current_user, "",[])}.to raise_error
  end

  it "should raise an ArgumentError executes get_solution_user_ids  if no parameters were passed" do
    expect {Cloud::UserManager.get_user_accepted_invites}.to raise_error(ArgumentError, "wrong number of arguments (0 for 3)")
  end

  it "should raise an ArgumentError executes get_solution_user_ids  if less than three parameters were passed" do
    expect {Cloud::UserManager.get_user_accepted_invites("", "")}.to raise_error(ArgumentError, "wrong number of arguments (2 for 3)")
  end

  it "should raise an ArgumentError executes get_solution_user_ids  if more than three parameters were passed" do
    @data_set = []
    expect {@data_set.page(1).per(PER_PAGE)}.to raise_error(NoMethodError, "undefined method `page' for []:Array" )
  end

end