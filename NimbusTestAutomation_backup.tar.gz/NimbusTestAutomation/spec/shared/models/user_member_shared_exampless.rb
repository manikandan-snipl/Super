RSpec.shared_examples "an empty follower_ids array" do

    context "when followers are not present for the current_user as (New User) entity as User" do
      subject(:follower_ids)  {user.follower_ids}

      it "returns the following_ids data as empty array of the current user" do
        expect(follower_ids).to match_array([])
        expect(follower_ids).to be_empty
      end
    end

    context "when followers are not present for the current_user as (New Member) entity as Member" do
      subject(:follower_ids)  {member.follower_ids}

      it "returns the following_ids data as empty array of the current user(Member)" do
        expect(follower_ids).to match_array([])
        expect(follower_ids).to be_empty
      end
    end

  end

  RSpec.shared_examples "follower_ids array" do

    context "when Current User(User) is followed by @user1" do

      before (:each) do
        @user1 = create(:user)
        @user2 = create(:user)
        @follower = create(:follow, followable_id: user.id, follower_id: @user1.id,member_id: @user1.id )
      end

      subject(:follower_ids)  {user.follower_ids}

      it "returns the followers id as array of the @user1 id" do
        expect(follower_ids).to match_array([@user1.id])
        expect(follower_ids).not_to be_empty
        expect(follower_ids.length).to eq(1)
      end
    end

    context "when Current User(Member) is followed by @member1" do

      before (:each) do
        @member1 = create(:member)
        @member2 = create(:member)
        @follower = create(:inkwell_following, follower_id: @member1.id, followed_id: member.id )
      end

      subject(:follower_ids)  {member.follower_ids}

      it "returns the followers id as array of the @member1 id" do
        expect(follower_ids).to match_array([@member1.id])
        expect(follower_ids).not_to be_empty
        expect(follower_ids.length).to eq(1)
      end
    end
  end


  RSpec.shared_examples "it returns following_ids array as empty" do

    context "when followings are not present for the current_user as (New User) entity as User" do
      subject(:following_ids)  {user.following_ids}

      it "returns the following_ids data as empty array of the current user" do
        expect(following_ids).to match_array([])
        expect(following_ids).to be_empty
      end
    end

    context "when followings are not present for the current_user as (New Member) entity as Member" do
      subject(:following_ids)  {member.following_ids}

      it "returns the following_ids data as empty array of the current user(Member)" do
        expect(following_ids).to match_array([])
        expect(following_ids).to be_empty
      end
    end

  end

  RSpec.shared_examples "it returns following_ids array" do

    context "when Current User(User) is following a @user1" do

      before (:each) do
        @user1 = create(:user)
        @user2 = create(:user)
        @follower = create(:follow, followable_id: @user1.id, follower_id: user.id,member_id: user.id )
        @follower = create(:follow, followable_id: @user1.id, follower_id: @user2.id,member_id: @user2.id )
      end

      subject(:following_ids)  {user.following_ids}

      it "returns the followers id as array of the @user1 id" do
        expect(following_ids).to match_array([@user1.id])
        expect(following_ids).not_to be_empty
        expect(following_ids.length).to eq(1)
      end
    end

    context "when Current User(Member) is following a @member1 and @member2" do

      before (:each) do
        @member1 = create(:member)
        @member2 = create(:member)
        @follower = create(:inkwell_following, follower_id: member.id, followed_id: @member1.id )
        @follower = create(:inkwell_following, follower_id: member.id, followed_id: @member2.id )
      end

      subject(:following_ids)  {member.following_ids}

      it "returns the followers id as array of the @member1,@member2 ids" do
        expect(following_ids).to match_array([@member1.id, @member2.id])
        expect(following_ids).not_to be_empty
        expect(following_ids.length).to eq(2)
      end
    end
  end


  RSpec.shared_examples "it returns member_short_info as a array" do

    context "when calling member_short_info('follower')" do

      context "when no followers were found as User instance" do
        let(:entity) {user}
        let(:type) {'follower'}
        it_behaves_like "it returns member_short_info resultset as empty"
      end

      context "when no followers were found as Member instance" do
        let(:entity) {member}
        let(:type) {'follower'}
        it_behaves_like "it returns member_short_info resultset as empty"
      end

      context "when followers found User instance " do
        let(:entity) {user}
        let(:entity_type) {user.class_name}
        let(:type) {'follower'}
        it_behaves_like "it returns member_short_info resultset as array"
      end

      context "when followers found Member instance " do
        let(:entity) {member}
        let(:entity_type) {member.class_name}
        let(:type) {'follower'}
        it_behaves_like "it returns member_short_info resultset as array"
      end

    end

    context "when calling member_short_info('following')" do

      context "when no following were found as User instance" do
         let(:entity) {user}
         let(:type) {'following'}
         it_behaves_like "it returns member_short_info resultset as empty"
      end

      context "when no following were found as Member instance" do
        let(:entity) {member}
        let(:type) {'following'}
        it_behaves_like "it returns member_short_info resultset as empty"
      end

      context "when followings found User instance " do
        let(:entity) {user}
        let(:entity_type) {user.class_name}
        let(:type) {'following'}
        it_behaves_like "it returns member_short_info resultset as array"
      end

      context "when followings found Member instance " do
        let(:entity) {member}
        let(:entity_type) {member.class_name}
        let(:type) {'following'}
        it_behaves_like "it returns member_short_info resultset as array"
      end
    end
  end

  RSpec.shared_examples "member_short_info with failures" do

    context "when calling member_short_info as User Instance" do
      it "should raise an ArgumentError error if more than one parameters passed" do
        expect {user.member_short_info("","")}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if no parameters were passed" do
        expect {user.member_short_info}.to raise_error(ArgumentError)
      end
    end

    context "when calling member_short_info as Member Instance" do
      it "should raise an ArgumentError error if more than one parameters passed" do
        expect {member.member_short_info("","")}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if no parameters were passed" do
        expect {member.member_short_info}.to raise_error(ArgumentError)
      end
    end

  end

  RSpec.shared_examples "it returns member_short_info resultset as empty" do

    context "when no matches were found " do
      subject(:result) {type == 'following' ? entity.following_ids : entity.follower_ids}

      it "checks the matching presence and return false" do
        expect(result.present?).to be false
      end

      it "should returns result as empty array" do
        expect(result).to match_array([])
        expect(entity.member_short_info(type)).to be_empty
      end
    end
  end


  RSpec.shared_examples "it returns member_short_info resultset as array" do

    context "when matches were found " do

      before (:each) do
        @record1 = entity_type == 'User' ? create(:user) : create(:member)
        @record2 = entity_type == 'User' ? create(:user) : create(:member)

        if type == 'following'
          @follow_record1 = entity_type == 'User' ? create(:follow, followable_id: @record1.id, follower_id: entity.id,member_id: entity.id ) : create(:inkwell_following, follower_id: entity.id, followed_id: @record2.id )
        else
          @follow_record1 = entity_type == 'User' ? create(:follow, followable_id: entity.id, follower_id: @record1.id,member_id: @record1.id ) : create(:inkwell_following, follower_id: @record2.id, followed_id: entity.id )
        end
      end

      subject(:result) {type == 'following' ? entity.following_ids : entity.follower_ids}

      subject(:result_set) do
        if type == 'following'
          entity_type == 'User' ? entity.all_following.reject{|c| c.class_name != 'User'} : entity.followings
        else
          entity.followers
        end
      end

        it "checks the matched data's presence and return true" do
          expect(result.present?).to be true
        end

        it "returns the matched data set" do
          members = entity_type.constantize.where(id: result,status: ACTIVE)
          expect(members.to_a).to eq(result_set)
          expect(members.to_a).not_to be_empty
        end

      it "should returns result array with short information's of matched users" do
        data = []
        result_set.each{|m| m_hash = {}; data << m_hash.merge!(unique_id: m.id,first_name: m.first_name,last_name: m.last_name,profile_pic: m.profile_pic,peer_id: m.get_peer_id)}
        collection = entity.member_short_info(type)
        expect(collection).not_to be_empty
        expect(collection).to have(result.length).items
        expect(collection).to match_array(data)
      end

    end
  end

  RSpec.shared_examples "it returns member_information's" do

    context "when calling member_info as  User instance" do
      let(:entity) {user}
      #let(:type) {'following'}
      it_behaves_like "it returns member_short_profile information as hash"
      it_behaves_like "member_info method with failures"
    end

    context "when calling member_info as  Member instance" do
      let(:entity) {member}
      #let(:type) {'following'}
      it_behaves_like "it returns member_short_profile information as hash"
      it_behaves_like "member_info method with failures"
    end
  end

  RSpec.shared_examples "it returns member_short_profile information as hash" do

    subject(:solution) {BaseModel.get_prod_or_sol_name(entity.invite_code)}

    it "it returns solution name as nimbus app if BaseModel.get_prod_or_sol_name("") - invite code is not present in method call" do
      result = BaseModel.get_prod_or_sol_name("")
      expect(result).to eq(" nimbus app")
      expect(result).not_to be_a(Array)
      expect(result).to be_a(String)
    end

    it "finds the product solution data as array" do
      expect(solution).to be_a(Array)
    end

    context "it executes #member_short_info" do
      it_behaves_like "it returns member_short_info as a array"
    end

    context "returns a result set" do
      let(:member_short_profile) {entity.member_info}

      it "returns a result as hash" do
        result = entity.member_info
        p result.inspect
        expect(result).to be_a(Hash)
        expect(result).to include(:unique_id, :username, :npi, :first_name, :last_name, :phone_number, :email, :email_id, :is_online, :about_status, :profile_pic, :user_or_member_type, :address, :specialization, :hospital_affiliation, :eduction, :board_certification, :followers, :followings, :member_followers, :member_followings)
      end

      it_behaves_like "returns result set information data"

    end

    context "check result values in resulting hash" do
      subject(:member_short_profile) {entity.member_info}

      it "check the result hash should include the member_followers key and the result value" do
        expect(member_short_profile[:member_followers]).to be_a(Array)
        expect(member_short_profile[:member_followers]).to match_array(entity.member_short_info('follower'))

      end

      it "check the result hash should include the member_followings key and the result value" do
        expect(member_short_profile[:member_followings]).to be_a(Array)
        expect(member_short_profile[:member_followings]).to match_array(entity.member_short_info('following'))
      end

      it "check the result hash should include the member_followings key and the result value" do
        expect(member_short_profile[:address]).to be_a(Array)
        expect(member_short_profile[:address]).to match_array(entity.member_addresses)
      end

      it "check the result hash should include the member_followings key and the result value" do
        expect(member_short_profile[:specialization]).to be_a(Array)
        expect(member_short_profile[:specialization]).to match_array(entity.extended_profile('s','arr'))
      end

      it "check the result hash should include the member_followings key and the result value" do
        expect(member_short_profile[:hospital_affiliation]).to be_a(Array)
        expect(member_short_profile[:hospital_affiliation]).to match_array(entity.extended_profile('h','arr'))
      end

      it "check the result hash should include the member_followings key and the result value" do
        expect(member_short_profile[:followers]).to be_a(Array)
        expect(member_short_profile[:followers]).to match_array(entity.followers_row)
      end

      it "check the result hash should include the member_followings key and the result value" do
        expect(member_short_profile[:followings]).to be_a(Array)
        expect(member_short_profile[:followings]).to match_array(entity.followings_row)
      end

    end
  end

  RSpec.shared_examples "member_info method with failures" do

    it "raises an error get_prod_or_sol_name with no parameters passing" do
      expect {BaseModel.get_prod_or_sol_name}.to raise_error(ArgumentError, "wrong number of arguments (0 for 1)")
    end

    it "raises an error get_prod_or_sol_name with more than one parameters passing" do
      expect {BaseModel.get_prod_or_sol_name("", "")}.to raise_error(ArgumentError, "wrong number of arguments (2 for 1)")
    end

    it_behaves_like "member_short_info with failures"

  end

  RSpec.shared_examples "execute member_following method properly" do

    context "when calling member_following as  User instance" do
      let(:entity) {user}
      let(:entity_type) {'User'}
      it_behaves_like "returns the member following information of the given user"
    end

    context "when calling member_following as  Member instance" do
      let(:entity) {member}
      let(:entity_type) {'Member'}
      it_behaves_like "returns the member following information of the given user"
    end

  end


  RSpec.shared_examples "returns the member following information of the given user" do

    context "when no matching found for following records" do
      subject(:followings) {entity.class_name == 'User' ? entity.all_following.reject{|c| c.class_name != 'User'} : entity.followings}

      it "returns the following list as empty" do

        if entity_type == 'User'
          expect(followings).to be_a(Array)
          expect(followings).to match_array([])
          expect(followings).to be_empty
          expect(followings).to have(0).items
        else
          expect(followings).not_to be_a(Array)
          expect(followings).to be_a(ActiveRecord::Associations::CollectionProxy)
          expect(followings).to have(0).items
        end
      end

      it "returns resultset as empty" do
        result = entity.member_following
        expect(result).to match_array(followings)
        expect(result).to be_empty
        expect(result).to have(0).items
      end

    end

    context "when matching found for following records" do

      before (:each) do
        @record1 = entity_type == 'User' ? create(:user) : create(:member)
        @record2 = entity_type == 'User' ? create(:user) : create(:member)
        @follow_record1 = entity_type == 'User' ? create(:follow, followable_id: @record1.id, follower_id: entity.id,member_id: entity.id ) : create(:inkwell_following, follower_id: entity.id, followed_id: @record2.id )
        @follow_record2 = entity_type == 'User' ? create(:follow, followable_id: entity.id, follower_id: @record1.id,member_id: @record1.id ) : create(:inkwell_following, follower_id: @record2.id, followed_id: entity.id )
      end

      subject(:followings) {entity.class_name == 'User' ? entity.all_following.reject{|c| c.class_name != 'User'} : entity.followings}
      subject(:result_set) {entity.member_following}


      it "returns the following list as records" do

        if entity_type == 'User'
          expect(followings).to be_a(Array)
          expect(followings).to match_array([@record1])
          expect(followings).not_to be_empty
          expect(followings).to have(result_set.length).items
        else
          expect(followings).not_to be_a(Array)
          expect(followings).to be_a(new_record::Associations::CollectionProxy)
          expect(followings).to have(result_set.length).items
        end
      end

      #it_behaves_like "it returns member_information's"

      context "returns a result set" do
        let(:member_short_profile) {""}
        it "returns resultset as array of hash" do
          followings_arr = []
          followings.each{|following| followings_arr << following.member_info.merge!(follow: 'yes')}
          expect(result_set).to match_array(followings_arr)
          expect(result_set).not_to be_empty
          expect(result_set).to have(followings_arr.length).items
        end

        it "should return each item in result_set as Hash and key values" do
          expect(result_set.first).to include(:unique_id, :username, :npi, :first_name, :last_name, :phone_number, :email, :email_id, :is_online, :about_status, :profile_pic, :user_or_member_type, :address, :specialization, :hospital_affiliation, :eduction, :board_certification, :followers, :followings, :member_followers, :member_followings, :follow)
        end

      end
    end
  end

  RSpec.shared_examples "execute member_followers method properly" do

    context "when calling member_followers as  User instance" do
      let(:entity) {user}
      let(:entity_type) {'User'}
      it_behaves_like "returns the member followers information of the given user"
    end

    context "when calling member_followers as  Member instance" do
      let(:entity) {member}
      let(:entity_type) {'Member'}
      it_behaves_like "returns the member followers information of the given user"
    end

  end

  RSpec.shared_examples "returns the member followers information of the given user" do

    context "when no matching found for following records" do
      subject(:followers) {entity.followers}

      it "returns the following list as empty" do

        if entity_type == 'User'
          expect(followers).to be_a(Array)
          expect(followers).to match_array([])
          expect(followers).to be_empty
          expect(followers).to have(0).items
        else
          expect(followers).not_to be_a(Array)
          expect(followers).to be_a(ActiveRecord::Associations::CollectionProxy)
          expect(followers).to have(0).items
        end
      end

      it "returns resultset as empty" do
        result = entity.member_followers
        expect(result).to match_array(followers)
        expect(result).to be_empty
        expect(result).to have(0).items
      end

    end

    context "when matching found for following records" do

      before (:each) do
        @record1 = entity_type == 'User' ? create(:user) : create(:member)
        @record2 = entity_type == 'User' ? create(:user) : create(:member)
        @follow_record1 = entity_type == 'User' ? create(:follow, followable_id: entity.id, follower_id: @record1.id,member_id: @record1.id ) : create(:inkwell_following, follower_id: @record2.id, followed_id: entity.id )
        @follow_record2 = entity_type == 'User' ? create(:follow, followable_id: entity.id, follower_id: @record2.id,member_id: @record1.id ) : create(:inkwell_following, follower_id: @record1.id, followed_id: entity.id )
      end

      subject(:followers) {entity.followers}
      subject(:result_set) {entity.member_followers}


      it "returns the following list as records" do

        if entity_type == 'User'
          expect(followers).to be_a(Array)
          expect(followers).to match_array([@record1,@record2])
          expect(followers).not_to be_empty
          expect(followers).to have(result_set.length).items
        else
          expect(followers).not_to be_a(Array)
          expect(followers).to be_a(ActiveRecord::Associations::CollectionProxy)
          expect(followers).to have(result_set.length).items
        end
      end

      context "returns a result set" do
        let(:member_short_profile) {""}
        it "returns resultset as array of hash" do
          followers_arr = []
          followers.each do |follower|
            if entity_type == 'User'
              expect(entity.class_name.to_s).to eq(entity_type)
              follow = entity.followed?(follower,nil) ? 'yes' : 'no'
              expect{entity.followed?(follower)}.to raise_error(ArgumentError)
              expect(follow).to eq("no")
            else
              expect(entity.class_name.to_s).to eq(entity_type)
              follow = (entity.follow? follower) ? 'yes' : 'no'
              expect{entity.follow? follower,""}.to raise_error(ArgumentError)
              expect(follow).to eq("no")
            end
            followers_arr << follower.member_info.merge!(follow: follow)
          end
          expect(result_set).to match_array(followers_arr)
          expect(result_set).not_to be_empty
          expect(result_set).to have(followers_arr.length).items
        end

        it "should return each item in result_set as Hash and key values" do
          expect(result_set.first).to include(:unique_id, :username, :npi, :first_name, :last_name, :phone_number, :email, :email_id, :is_online, :about_status, :profile_pic, :user_or_member_type, :address, :specialization, :hospital_affiliation, :eduction, :board_certification, :followers, :followings, :member_followers, :member_followings, :follow)
        end
      end
    end
  end

  RSpec.shared_examples "returns result set information data" do
    context "check result values in resulting hash" do

      it "check the result hash should include the member_followers key and the result value" do
        expect(member_short_profile[:member_followers]).to be_a(Array)
        expect(member_short_profile[:member_followers]).to match_array(entity.member_short_info('follower'))
      end

      it "check the result hash should include the member_followings key and the result value" do
        expect(member_short_profile[:member_followings]).to be_a(Array)
        expect(member_short_profile[:member_followings]).to match_array(entity.member_short_info('following'))
      end

      it "check the result hash should include the member_followings key and the result value" do
        expect(member_short_profile[:address]).to be_a(Array)
        expect(member_short_profile[:address]).to match_array(entity.member_addresses)
      end

      it "check the result hash should include the member_followings key and the result value" do
        expect(member_short_profile[:specialization]).to be_a(Array)
        expect(member_short_profile[:specialization]).to match_array(entity.extended_profile('s','arr'))
      end

      it "check the result hash should include the member_followings key and the result value" do
        expect(member_short_profile[:hospital_affiliation]).to be_a(Array)
        expect(member_short_profile[:hospital_affiliation]).to match_array(entity.extended_profile('h','arr'))
      end

      it "check the result hash should include the member_followings key and the result value" do
        expect(member_short_profile[:followers]).to be_a(Array)
        expect(member_short_profile[:followers]).to match_array(entity.followers_row)
      end

      it "check the result hash should include the member_followings key and the result value" do
        expect(member_short_profile[:followings]).to be_a(Array)
        expect(member_short_profile[:followings]).to match_array(entity.followings_row)
      end

    end
  end

  RSpec.shared_examples "execute member_following method with failures" do

  end


  RSpec.shared_examples "returns full name of the given User" do
    it "returns a full name as a string" do
      expect(entity.full_name).to eq("#{entity.first_name} #{entity.last_name}")
    end
  end

  RSpec.shared_examples "returns full name of the given User" do
    it "returns a full name as a string" do
      expect(entity.full_name).to eq("#{entity.first_name} #{entity.last_name}")
    end
  end

