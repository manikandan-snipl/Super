RSpec.shared_examples "an empty follower_ids array" do

end