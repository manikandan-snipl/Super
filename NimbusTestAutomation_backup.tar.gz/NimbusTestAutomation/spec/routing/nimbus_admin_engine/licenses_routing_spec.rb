require 'rails_helper'

module NimbusAdminEngine
  RSpec.describe LicensesController, type: :routing do
  routes { NimbusAdminEngine::Engine.routes }
  it "recognizes and generates #index" do
    expect(get: "/licenses").to be_routable
  end

  it "recognizes and generates #search_licenses" do
    expect(get: "/licenses/search_licenses").to route_to(controller: "nimbus_admin_engine/licenses", action: "search_licenses")
  end

end
end
