require 'rails_helper'

module NimbusAdminEngine
  RSpec.describe AdminsController, type: :routing do
  routes { NimbusAdminEngine::Engine.routes }
  it "recognizes and generates #index" do
    expect(get: "/admins").to be_routable
  end

  it "recognizes and generates #admin_start" do
    expect(get: "/admins/admin_start").to route_to(controller: "nimbus_admin_engine/admins", action: "admin_start")
  end


  it "recognizes and generates #search_filter" do
    expect(get: "/admins/search_filter").to route_to(controller: "nimbus_admin_engine/admins", action: "search_filter")
  end


  it "recognizes and generates #update_invite_user_status" do
    expect(post: "/admins/update_invite_user_status").to route_to(controller: "nimbus_admin_engine/admins", action: "update_invite_user_status")
  end

  it "recognizes and generates #get_group_users_data" do
    expect(get: "/admins/get_group_users_data").to route_to(controller: "nimbus_admin_engine/admins", action: "get_group_users_data")
  end

end
end