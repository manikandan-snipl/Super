require 'rails_helper'

module NimbusAdminEngine
  RSpec.describe AdminUsersController, type: :routing do
  routes { NimbusAdminEngine::Engine.routes }
  it "recognizes and generates #index" do
    expect(get: "/admin_users").to be_routable
  end

  it "recognizes and generates #edit" do
    expect(get: "/admin_users/1/edit").to route_to(controller: "nimbus_admin_engine/admin_users", action: "edit", id: "1")
  end

  it "recognizes and generates #create" do
    expect(post: "/admin_users").to route_to(controller: "nimbus_admin_engine/admin_users", action: "create")
  end

  it "recognizes and generates #update" do
    expect(put: "/admin_users/1").to route_to(controller: "nimbus_admin_engine/admin_users", action: "update", id: "1")
  end

  it "recognizes and generates #destroy" do
    expect(delete: "/admin_users/1").to route_to(controller: "nimbus_admin_engine/admin_users", action: "destroy", id: "1")
  end

  it "recognizes and generates #manage_group" do
    expect(get: "/admin_users/manage_group").to route_to(controller: "nimbus_admin_engine/admin_users", action: "manage_group")
  end

  it "recognizes and generates #import" do
    expect(get: "/admin_users/import").to route_to(controller: "nimbus_admin_engine/admin_users", action: "import")
  end

  it "recognizes and generates #user_import_and_invite" do
    expect(get: "/admin_users/user_import_and_invite").to route_to(controller: "nimbus_admin_engine/admin_users", action: "user_import_and_invite")
  end

  it "recognizes and generates #update_user_status" do
    expect(get: "/admin_users/update_user_status").to route_to(controller: "nimbus_admin_engine/admin_users", action: "update_user_status")
  end

end
end
