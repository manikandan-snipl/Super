require 'rails_helper'

module NimbusAdminEngine
  RSpec.describe AdminUsersController, type: :routing do
  routes { NimbusAdminEngine::Engine.routes }
  it "recognizes and generates #index" do
    expect(get: "/admin_groups").to be_routable
  end

  it "recognizes and generates #edit" do
    expect(get: "/admin_groups/1/edit").to route_to(controller: "nimbus_admin_engine/admin_groups", action: "edit", id: "1")
  end

  it "recognizes and generates #create" do
    expect(post: "/admin_groups").to route_to(controller: "nimbus_admin_engine/admin_groups", action: "create")
  end

  it "recognizes and generates #update" do
    expect(put: "/admin_groups/1").to route_to(controller: "nimbus_admin_engine/admin_groups", action: "update", id: "1")
  end

  it "recognizes and generates #destroy" do
    expect(delete: "/admin_groups/1").to route_to(controller: "nimbus_admin_engine/admin_groups", action: "destroy", id: "1")
  end

  it "recognizes and generates #get_admin_users_list" do
    expect(get: "/admin_groups/get_admin_users_list").to route_to(controller: "nimbus_admin_engine/admin_groups", action: "get_admin_users_list")
  end

end
end
