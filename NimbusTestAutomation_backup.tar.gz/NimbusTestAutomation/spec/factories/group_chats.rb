FactoryGirl.define do
  factory :group_chat , :class => CommonEngine::GroupChat do
    sequence(:name){|n| "group #{n}"}
    info  "Dhh"
    group_type  '200'
    created_by  '22'
    updated_by {}
    status  '1'
  end
end

