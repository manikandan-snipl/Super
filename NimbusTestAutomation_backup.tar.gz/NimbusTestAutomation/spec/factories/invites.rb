FactoryGirl.define do
  factory :invite , :class => CommonEngine::Invite do
    from_type  "User"
    from_id  '4'
    contact_id {}
    invite_limit {}
    email_from  "topics1@supranimbus.co"
    sequence(:email_to) { |i| "user#{i}@example.com" }
    created_by ""
    status  '3'
    phone_number { "#{rand(10**9..10**10)}"}
    sequence(:first_name){|n| "test #{n}"}
    sequence(:last_name){|n| "test #{n}"}
    sequence(:invite_code){|n| "Code #{n}"}
    license_code { "#{invite_code}"}
  end
end

