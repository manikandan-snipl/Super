FactoryGirl.define do
  factory :group_user , :class => CommonEngine::GroupUser do
    group_chat_id  '1'
    user_id  '1'
    status  '1'
    created_by '1'
  end
end

