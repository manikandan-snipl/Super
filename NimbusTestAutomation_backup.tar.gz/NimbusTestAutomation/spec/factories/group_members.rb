FactoryGirl.define do
  factory :group_member , :class => CommonEngine::GroupMember do
    group_chat_id  '1'
    member_id  '1'
    status  '1'
    created_by '1'
  end
end

