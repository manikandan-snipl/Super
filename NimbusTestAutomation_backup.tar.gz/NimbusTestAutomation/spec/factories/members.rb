FactoryGirl.define do
  factory :member , :class => CommonEngine::Member do
    username  ''
    sequence(:email) { |n| "krishna#{n}@example.com" }
    sequence(:first_name) { |n| "kutty#{n}" }
    sequence(:last_name) { |n| "krishna#{n}" }
    alt_email "velrangitham.ms@gmail.com"
    phone { "#{rand(10**9..10**10)}"}
    authentication_token "uPziTheZ8UGEfdeqTDmB"
    encrypted_password ''
    password_salt ''
    invite_code { "#{rand(10**9..10**10)}"}
  end
end