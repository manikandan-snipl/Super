FactoryGirl.define do
  factory :follow , :class => ::Follow do
    followable_id  '4'
    followable_type  "CommonEngine::User"
    follower_id  '1'
    follower_type  "CommonEngine::User"
    blocked false
    member_id  ''
    user_id  ''
    status  1
  end
end

