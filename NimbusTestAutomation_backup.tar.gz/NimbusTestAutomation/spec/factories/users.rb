FactoryGirl.define do
  factory :user , :class => CommonEngine::User do
    sequence(:first_name){|n| "Vel #{n}"}
    sequence(:last_name){|n| "Pradeep #{n}"}
    username  {"#{first_name}  #{last_name}"}
    sequence(:email) { |i| "pradeep.kumar#{i}@supranmibus.co" }
    company "Supra Nimbus Corporation"
    alt_email "velrangitham.ms@gmail.com"
    phone { "#{rand(10**9..10**10)}"}
    authentication_token "uPziTheZ8UGEfdeqTDmB"
    encrypted_password ''
    password_salt ''
    sequence(:invite_code){|n| "#{n}"}
    admin 'true'
  end
end
#
#factory :user do
#  username            { FactoryGirl.generate(:username) }
#  email               { Faker::Internet.email }
#  first_name          { Faker::Name.first_name }
#  last_name           { Faker::Name.last_name }
#  title               { FactoryGirl.generate(:title) }
#  company             { Faker::Company.name }
#  alt_email           { Faker::Internet.email }
#  phone               { Faker::PhoneNumber.phone_number }
#  mobile              { Faker::PhoneNumber.phone_number }
#  aim nil
#  yahoo nil
#  google nil
#  skype nil
#  admin false
#  password_hash       { SecureRandom.hex(64) }
#  password_salt       { SecureRandom.hex(64) }
#  persistence_token   { SecureRandom.hex(64) }
#  perishable_token    { SecureRandom.hex(10) }
#  single_access_token nil
#  last_request_at     { FactoryGirl.generate(:time) }
#  current_login_at    { FactoryGirl.generate(:time) }
#  last_login_at       { FactoryGirl.generate(:time) }
#  last_login_ip "127.0.0.1"
#  current_login_ip "127.0.0.1"
#  login_count         { rand(100) + 1 }
#  deleted_at nil
#  updated_at          { FactoryGirl.generate(:time) }
#  created_at          { FactoryGirl.generate(:time) }
#  suspended_at nil
#  password "password"
#  password_confirmation "password"
#end