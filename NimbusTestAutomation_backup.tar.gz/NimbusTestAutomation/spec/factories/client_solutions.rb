FactoryGirl.define do
  factory :client_solution , :class => CommonEngine::ClientSolution do
    source  {}
    client_id  '4'
    solution_id  '6'
    solution_license_code  '0'
    solution_license_type  '0'
    solution_license_desc {}
    license_start_date  ''
    license_end_date  ''
    status  '1'
    status_desc   {}
    created_by     {}
    updated_by      {}
    deleted_by      {}
    comment          {}
    license_max_limit  '3'
  end
end

