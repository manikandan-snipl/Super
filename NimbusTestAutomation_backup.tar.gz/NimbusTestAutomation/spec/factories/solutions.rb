FactoryGirl.define do
  factory :solution , :class => CommonEngine::Solution do
    source  "in-house"
    solution_type  {}
    name  "FaceGuru"
    package_type  '1'
    price  '500.0'
    license_type  "per user"
    billing_type  "per month"
    billing_frequency  {}
    status  "active"
    status_desc  {}
  end
end

