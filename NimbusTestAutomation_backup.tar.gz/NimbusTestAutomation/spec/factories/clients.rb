FactoryGirl.define do
  factory :client , :class => CommonEngine::Client do
    source {}
    user_id  '1'
    legal_name  "Celgene Health Incorporated"
    display_name {}
    short_name  {}
    assigned_to  {}
    master_license_code  "AAA"
    license_type  "per year"
    license_type_desc {}
    license_start_date  ""
    license_end_date     ""
    status               {}
    access                {}
    #website
    #linkedin_url
    #facebook_url
    #twitter_url
    #other_url1_name
    #other_url1
    #other_url2_name
    #other_url2
    #toll_free_phone
    #phone
    #fax
    #email1
    #email2
    #background_info
    #rating  0
    #category
    #subscribed_users
    schema_name  "aa"
    schema_owner "bb"
    schema_code  "ccc"
    #schema_key
    #status_desc
    #created_by
    #updated_by
    #deleted_by
    #deleted_at
    #comment
  end
end

