FactoryGirl.define do
  factory :client_solutions_user , :class => CommonEngine::ClientSolutionsUser do
    source {}
    client_solution_id  '21'
    user_id  '1'
    user_license_code  '0'
    user_license_type  '0'
    user_license_desc    {}
    #license_start_date  '2015-08-11 00:00:00'
    #license_end_date  '2015-11-19:00:00:00'
    status  '1'
    status_desc {}
    created_by  '42'
  end
end

