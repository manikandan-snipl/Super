FactoryGirl.define do
  factory :inkwell_following , :class => ::InkwellFollowing do
    follower_id  '1'
    followed_id  '2'
    status  '1'
  end
end

