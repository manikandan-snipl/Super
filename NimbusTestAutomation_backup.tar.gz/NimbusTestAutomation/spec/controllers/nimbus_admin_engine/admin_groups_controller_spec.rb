require 'rails_helper'

module NimbusAdminEngine
  RSpec.describe AdminGroupsController, type: :controller do
  routes { NimbusAdminEngine::Engine.routes }
  before (:each) do
    @user = FactoryGirl.create(:user)
    sign_in @user
    @client = FactoryGirl.create(:client, user_id: @user.id)
    @solution = FactoryGirl.create(:solution)
    @client_solution = FactoryGirl.create(:client_solution, client_id: @client.id,solution_id: @solution.id)
    @client_solutions_user = FactoryGirl.create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id )
  end

  context "when admin user not logged in" do
    it "blocks unauthenticated access" do
      sign_in nil
      get :index
      expect(response).to redirect_to(new_user_session_path)
    end
  end


  describe "GET index" do
    context "viewing the Groups page" do
      subject(:groups) { 4.times { FactoryGirl.create(:group_chat, created_by: @user.id) } }
      subject(:group_chat_manager) { Cloud::GROUP_CHAT_MANAGER }

      it "checks GroupChatManager class having the get_all_groups method" do
        get :index
        expect(group_chat_manager).to respond_to(:get_all_groups)
      end

      it "checks get_user_licenses method is accepting with 1 arguments" do
        get :index
        expect(group_chat_manager).to respond_to(:get_all_groups).with(2).argument
      end

      it "assigns @results to the view" do
        get :index
        allow(group_chat_manager).to receive(:get_all_groups)
        groups = group_chat_manager.get_all_groups(@user, [])
        result = expect(group_chat_manager).to have_received(:get_all_groups)
        controller.instance_variable_set(:@results, result)
        expect(assigns(:results)).to eq(result)
      end

      it "assigns @admin_group user as a new record" do
        get :index
        controller.instance_variable_set(:@admin_group, FactoryGirl.build(:group_chat))
      end

      it "should render the index template" do
        get :index
        expect(response).to render_template("index")
      end
    end

  end

  describe "Get #Edit" do
    context "Editing the Group  valid attributes" do
      subject(:group) { FactoryGirl.create(:group_chat, created_by: @user.id) }
      subject(:group_chat_manager) { Cloud::GROUP_CHAT_MANAGER }

      it "assign the @admin_group" do
        controller.instance_variable_set(:@admin_group, group)
        expect(assigns(:admin_group)).to eq(group)
      end

      it "checks GroupChatManager class having the get_group_users_info method" do
        xhr :get, 'edit',  {:id => group.id}
        expect(group_chat_manager).to respond_to(:get_group_users_info)
      end

      it "checks get_user_licenses method is accepting with 1 arguments" do
        xhr :get, 'edit',  {:id => group.id}
        expect(group_chat_manager).to respond_to(:get_group_users_info).with(1).argument
      end

      it "access the get_user_created_groups method and assign results to @groups" do
        xhr :get, 'edit',  {:id => group.id}
        allow(group_chat_manager).to receive(:get_group_users_info)
        group_users = group_chat_manager.get_group_users_info(group.id)
        expect(group_chat_manager).to have_received(:get_group_users_info)
        controller.instance_variable_set(:@group_users, group_users)
        expect(assigns(:group_users)).to eq(group_users)
      end

      it "renders the page with success response" do
        xhr :get, 'edit',  {:id => group.id}
        expect(response).to render_template('edit')
      end
    end

  end

  describe "DELETE #destroy" do
    context "destroying the record" do

      subject(:group) { FactoryGirl.create(:group_chat, created_by: @user.id) }
      subject(:group_chat_manager) { Cloud::GROUP_CHAT_MANAGER }

      it "assign the @admin_group" do
        controller.instance_variable_set(:@admin_group, group)
        expect(assigns(:admin_group)).to eq(group)
      end

      it "destroys the requested crud" do
        xhr :delete, 'destroy',  {:id => group.id}
      end

      it "renders the page with success response" do
        xhr :delete, 'destroy',  {:id => group.id}
        expect(response).to render_template('destroy')
      end
    end

  end

  describe 'POST #create' do
    subject(:params) {{"group_chat"=>{"name"=>"aaa", "user_ids"=>["", "49"]}, "group_view"=>"", "query"=>"Bala8 Hari8"} }
    subject(:member_ids) {admin_group_params["user_ids"].delete_if{|id|  id == ""} }

    subject(:invalid_params) {{"group_chat"=>{"name"=>"", "user_ids"=>["", "49"]}} }
    subject(:group_chat_manager) { Cloud::GROUP_CHAT_MANAGER }
    context 'with valid attributes' do
      subject(:admin_group_params) {params["group_chat"]}
      it 'creates the Group' do
        xhr :post, 'create', {:group_chat => admin_group_params }
        expect(CommonEngine::GroupChat.count).to eq(1)
      end


      it "checks GroupChatManager class having the get_group_users_info method" do
        xhr :post, 'create', {:group_chat => admin_group_params }
        expect(group_chat_manager).to respond_to(:create_group_chat_with_members)
      end

      it "checks get_user_licenses method is accepting with 5 arguments" do
        xhr :post, 'create', {:group_chat => admin_group_params }
        expect(group_chat_manager).to respond_to(:create_group_chat_with_members).with(5).argument
      end

      it "access the get_user_created_groups method and assign results to @groups" do
        xhr :post, 'create', {:group_chat => admin_group_params }
        allow(group_chat_manager).to receive(:create_group_chat_with_members)
        @group_chat = group_chat_manager.create_group_chat_with_members(admin_group_params,member_ids,"",@user,'User')
        expect(group_chat_manager).to have_received(:create_group_chat_with_members)
        controller.instance_variable_set(:@group_chat, @group_chat)
        expect(assigns(:group_chat)).to eq(@group_chat)
      end

      it "renders the page with success response" do
        xhr :post, 'create', {:group_chat => admin_group_params }
        expect(response).to render_template('create')
      end
    end

    context 'with invalid attributes' do
      subject(:admin_group_params) {invalid_params["group_chat"]}
      subject(:params) {ActionController::Parameters.new(client: { short_name: 'Francesco' })}

      it "checks incoming params containing the key group_chat if not raise ActionController::ParameterMissing - Param not found error" do
        expect { params.require(:group_chat) }.to raise_error(ActionController::ParameterMissing)
      end

      it 'does not create the vehicle' do
        xhr :post, 'create', {:group_chat => admin_group_params }
        expect(CommonEngine::GroupChat.count).to eq(0)
      end

      it "renders the page with failure message" do
        xhr :post, 'create', {:group_chat => admin_group_params }
        expect(response).to render_template('create')
      end
    end
  end

  describe "PUT #update" do
    subject(:group_chat_manager) { Cloud::GROUP_CHAT_MANAGER }
    subject(:group) { FactoryGirl.create(:group_chat, created_by: @user.id) }
    subject(:group_users) {[@user].map{|user| FactoryGirl.create(:group_user, group_chat_id: group.id, user_id: user.id) } }
    subject(:group_user_manager_service) {Cloud::GroupUserManager}

    context "with valid attributes and params[:status_update] is not available" do
      subject(:params) {{"group_chat"=>{"name"=>group.name, "user_ids"=> group.group_users.map(&:id)}, "group_view"=>"", "query"=>"", "id"=>group.id} }
      subject(:group_chat_id) {params["id"]}
      subject(:admin_group_params) {params["group_chat"]}
      subject(:member_ids) {admin_group_params["user_ids"].delete_if{|id|  id == ""} }
      subject(:comment_body) {params[:comment_body] }
      subject(:old_array) { group_users.map(&:id)}
      subject(:existing_users) { []}
      subject(:new_users) { []}

      subject {member_ids.map {|data| status = old_array.include? (data.to_i); status == true ? existing_users.push(data.to_i) : new_users.push(data.to_i)}}

      subject(:removed_users) {old_array - existing_users}


      it "assigns to @admin_group" do
        controller.instance_variable_set(:@admin_group, group)
        expect(assigns(:admin_group)).to eq(group)
      end

      it "assigns to @comment_body" do
        controller.instance_variable_set(:@comment_body, comment_body)
        expect(assigns(:comment_body)).to eq(comment_body)
      end

      it "checks GroupChatManager class having the add_member method" do
        xhr :post, 'create', {:group_chat => admin_group_params }
        expect(group_user_manager_service).to respond_to(:add_member)
      end

      it "checks get_user_licenses method is accepting with 3 arguments" do
        xhr :post, 'create', {:group_chat => admin_group_params }
        expect(group_user_manager_service).to respond_to(:add_member).with(3).argument
      end

      it "access the get_user_created_groups method and assign results to @groups" do
        xhr :post, 'create', {:group_chat => admin_group_params }
        allow(group_user_manager_service).to receive(:add_member)
        allow(group_user_manager_service).to receive(:remove_member)
        @group_chat = group_user_manager_service.add_member(new_users,group_chat_id, @user)
        removed_users.each{|user| group_user_manager_service.remove_member(user,group_chat_id,@user)}
        expect(group_user_manager_service).to have_received(:add_member)
        expect(group_user_manager_service).to have_received(:remove_member)
      end

      it "updates the requested user information" do
        xhr :put, 'update',  {:id => group.id,:group_chat => admin_group_params }
      end

      it "renders the page with success response" do
        xhr :put, 'update',  {:id => group.id,:group_chat => admin_group_params }
        expect(response).to render_template('update')
      end
    end

    context "with invalid attributes" do
      subject(:invalid_params) {{"group_chat"=>{"name"=>"", "user_ids"=>["", "49"]}} }
      subject(:admin_group_params) {invalid_params["group_chat"]}
      subject(:params) {ActionController::Parameters.new(client: { short_name: 'Francesco' })}

      it "checks incoming params containing the key group_chat if not raise ActionController::ParameterMissing - Param not found error" do
        expect { params.require(:group_chat) }.to raise_error(ActionController::ParameterMissing)
      end

      it "renders the page with failure message" do
        xhr :post, 'create', {:group_chat => admin_group_params }
        expect(response).to render_template('create')
      end

    end
  end

end
end
