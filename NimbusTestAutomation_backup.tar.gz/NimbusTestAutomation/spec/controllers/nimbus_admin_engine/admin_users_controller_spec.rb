require 'rails_helper'

module NimbusAdminEngine
  RSpec.describe AdminUsersController, type: :controller do
  routes { NimbusAdminEngine::Engine.routes }
  before (:each) do
    @user = FactoryGirl.create(:user)
    sign_in @user
    @client = FactoryGirl.create(:client, user_id: @user.id)
    @solution = FactoryGirl.create(:solution)
    @client_solution = FactoryGirl.create(:client_solution, client_id: @client.id,solution_id: @solution.id)
    @client_solutions_user = FactoryGirl.create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id )
  end

  context "when admin user not logged in" do
    it "blocks unauthenticated access" do
      sign_in nil
      get :index
      expect(response).to redirect_to(new_user_session_path)
    end
  end

  describe "GET index" do
    context "when user logged in and the page is displaying users" do
      subject(:invite1) { FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email) }
      subject(:invite2) { FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email) }
      subject(:invites) { [invite1, invite2] }
      subject(:users){ invites.map{|invite| FactoryGirl.create(:user, first_name: invite.first_name, last_name: invite.last_name, email: invite.email_to, invite_code: invite.invite_code)}}

      it "assign the is_admin value true or false from params" do
        get :index
        controller.instance_variable_set(:@is_admin, false)
        expect(assigns(:is_admin)).to eq(false)
      end

      it "has to fetch invite_codes from invites sent by current_users" do
        get :index
        controller.instance_variable_set(:@invite_codes, [invite1.invite_code,invite2.invite_code])
        expect(assigns(:invite_codes)).to eq([invite1.invite_code,invite2.invite_code])
      end

      it "should retrieve admin users based on invite codes sent and accepted by the current user" do
        get :index
        controller.instance_variable_set(:@data_set, users)
        expect(assigns(:data_set)).to eq(users)
      end

      it "should assign the results to the view page" do
        get :index
        controller.instance_variable_set(:@results, users)
        expect(assigns(:results)).to eq(users)
      end

      it "should assign the new admin user" do
        get :index
        controller.instance_variable_set(:@admin_user, FactoryGirl.build(:user))
      end

      it "should render the index template" do
        get :index
        expect(response).to render_template("index")
      end
    end

    context "when user logged in and the page is not displaying admin users" do
      subject(:users){ []}

      it "has no matched invite_codes from invites sent by current_users" do
        get :index
        controller.instance_variable_set(:@invite_codes, [])
        expect(assigns(:invite_codes)).to eq([])
      end

      it "should assign empty list if the invite codes is assined as empty" do
        get :index
        controller.instance_variable_set(:@data_set, [])
        expect(assigns(:data_set)).to eq(users)
      end

      it "should assign the empty results object to the view page" do
        get :index
        controller.instance_variable_set(:@results, users)
        expect(assigns(:results)).to eq(users)
      end

      it "should assign the new admin user" do
        get :index
        controller.instance_variable_set(:@admin_user, FactoryGirl.build(:user))
      end

      it "should render the index template" do
        get :index
        expect(response).to render_template("index")
      end
    end
  end

  describe "Get #Edit" do
    context "with valid attributes" do
      subject(:invite1) { FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email) }
      subject(:invite2) { FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email) }
      subject(:invites) { [invite1, invite2] }
      subject(:users){ invites.map{|invite| FactoryGirl.create(:user, first_name: invite.first_name, last_name: invite.last_name, email: invite.email_to, invite_code: invite.invite_code)}}
      subject(:group_chat_manager) { Cloud::GROUP_CHAT_MANAGER }


      it "assign the user object to the @admin_user" do
        controller.instance_variable_set(:@admin_user, @user)
        expect(assigns(:admin_user)).to eq(@user)
      end

      it "assign the is_admin value true or false from params" do
        xhr :get, 'edit',  {:id => @user.id}
        controller.instance_variable_set(:@is_admin, false)
        expect(assigns(:is_admin)).to eq(false)
      end

      it "has to fetch invite_codes from invites sent by current_users" do
        xhr :get, 'edit',  {:id => @user.id}
        controller.instance_variable_set(:@invite_codes, [invite1.id,invite2.id])
        expect(assigns(:invite_codes)).to eq([invite1.id,invite2.id])
      end

      it "should retrieve admin users based on invite codes sent and accepted by the current user" do
        xhr :get, 'edit',  {:id => @user.id}
        controller.instance_variable_set(:@data_set, users)
        expect(assigns(:data_set)).to eq(users)
      end

      it "should assign the results to the view page" do
        xhr :get, 'edit',  {:id => @user.id}
        controller.instance_variable_set(:@results, users)
        expect(assigns(:results)).to eq(users)
      end

      it "checks GroupChatManager class having the get_user_created_groups method" do
        xhr :get, 'edit',  {:id => @user.id}
        expect(group_chat_manager).to respond_to(:get_user_created_groups)
      end

      it "checks get_user_licenses method is accepting with 1 arguments" do
        xhr :get, 'edit',  {:id => @user.id}
        expect(group_chat_manager).to respond_to(:get_user_created_groups).with(1).argument
      end

      it "access the get_user_created_groups method and assign results to @groups" do
        xhr :get, 'edit',  {:id => @user.id}
        allow(group_chat_manager).to receive(:get_user_created_groups)
        groups = group_chat_manager.get_user_created_groups(@admin_user)
        expect(group_chat_manager).to have_received(:get_user_created_groups)
        controller.instance_variable_set(:@groups, groups)
        expect(assigns(:groups)).to eq(groups)
      end

      it "renders the page with success response" do
        xhr :get, 'edit',  {:id => @user.id}
        expect(response).to render_template('edit')
      end

    end

  end

  describe "PUT #update" do
    context "with valid attributes" do
      subject(:params) {{"is_admin_data"=>"false", "user"=>{"first_name"=>"Testuser2", "last_name"=>"Iphone", "title"=>"", "admin"=>"0", "user_type"=>"", "contact"=>"", "phone"=>"7411231234", "mobile"=>"", "fax"=>"", "website"=>"", "email"=>"testuser2@supranimbus.co", "business_address_attributes"=>{"address_type"=>"Business", "street1"=>"", "street2"=>"", "city"=>"", "state"=>"", "zipcode"=>"", "country"=>""}, "tag_list"=>"", "user_ids"=>[""], "group_ids"=>[""]}, "assigned_to"=>{"assigned_to"=>""}, "comment_body"=>"", "id"=>"25"} }
      subject(:admin_users_params) {params["user"] }
      it "assigns to @admin_user" do
        controller.instance_variable_set(:@admin_user, @user)
        expect(assigns(:admin_user)).to eq(@user)
      end

      it "updates the requested user information" do
        xhr :put, 'update',  {:id => @user.id,:user => admin_users_params }
      end

      it "renders the page with success response" do
        xhr :put, 'update',  {:id => @user.id,:user => admin_users_params }
        expect(response).to render_template('update')
      end
    end

    context "with invalid attributes" do
      subject(:params) {ActionController::Parameters.new(client: { short_name: 'Francesco' })}
      it "checks incoming params containing the key user if not raise ActionController::ParameterMissing - Param not found error" do
        expect { params.require(:user) }.to raise_error(ActionController::ParameterMissing)
      end

    end
  end

  describe "DELETE #destroy" do
    context "with valid attributes" do
      subject(:params) {{"is_admin_data"=>"false", "user"=>{"first_name"=>"Testuser2", "last_name"=>"Iphone", "title"=>"", "admin"=>"0", "user_type"=>"", "contact"=>"", "phone"=>"7411231234", "mobile"=>"", "fax"=>"", "website"=>"", "email"=>"testuser2@supranimbus.co", "business_address_attributes"=>{"address_type"=>"Business", "street1"=>"", "street2"=>"", "city"=>"", "state"=>"", "zipcode"=>"", "country"=>""}, "tag_list"=>"", "user_ids"=>[""], "group_ids"=>[""]}, "assigned_to"=>{"assigned_to"=>""}, "comment_body"=>"", "id"=>"25"} }
      subject(:admin_users_params) {params["user"] }
      it "assigns to @admin_user" do
        controller.instance_variable_set(:@admin_user, @user)
        expect(assigns(:admin_user)).to eq(@user)
      end

      it "destroys the requested crud" do
        xhr :delete, 'destroy',  {:id => @user.id}
      end

      it "renders the page with success response" do
        xhr :delete, 'destroy',  {:id => @user.id}
        expect(response).to render_template('destroy')
      end
    end

  end

  #describe "Get #add_comments" do
  #  context "with valid attributes" do
  #    subject(:params) {{ "is_admin_data"=>"false", "user"=>{"email"=>"testuser2@supranimbus.co"}, "comment_body"=>"ssss", "id"=>"25"} }
  #    subject(:comment_body) {params[:comment_body] }
  #
  #    it "assigns to @admin_user" do
  #      controller.instance_variable_set(:@comment_body, comment_body)
  #      expect(assigns(:comment_body)).to eq(comment_body)
  #    end
  #
  #    it "checks User class having the add_comment_by_user method" do
  #      xhr :get, 'add_comments',  {:id => @user.id}
  #      allow_any_instance_of(User).to receive(:add_comment_by_user)
  #      @user.should_receive(:add_comment_by_user)
  #    end
  #
  #    it "renders the page with success response" do
  #      xhr :get, 'add_comments',  {:id => @user.id}
  #      expect(response).to render_template('add_comments')
  #    end
  #
  #  end
  #end

  describe "GET #import" do
    context "when user viewing the import page" do
      it "should render the index template" do
        get :import
        expect(response).to render_template("import")
      end
    end
  end

  describe "POST #user_import_and_invite" do
    context "when import or inviting record(s)" do
      subject(:params) {{ "add_user_type"=>"import","license_version"=>"Basic","tags"=>"", "invite"=>{"file"=>"invites.csv"}} }
      subject(:file) { params[:invite].present? ? params[:invite][:file] : ""}
      subject(:invite_service) { Cloud::INVITE_FRIEND }
      subject(:invite_hash) { params[:invite].present? ? {} : {"first_name" => params["first_name"],"last_name" => params["last_name"], "email"=> params["email"],"phone_number" => params["phone"],"license_code"=> params["license_code"]} }

      it "checks InviteFriend class having the import_and_invite method" do
        xhr :post, 'user_import_and_invite'
        expect(invite_service).to respond_to(:import_and_invite)
      end

      it "checks get_user_licenses method is accepting with 1 arguments" do
        xhr :post, 'user_import_and_invite'
        expect(invite_service).to respond_to(:import_and_invite).with(7).argument
      end

      it "access the get_user_created_groups method and assign results to @groups" do
        xhr :post, 'user_import_and_invite'
        allow(invite_service).to receive(:import_and_invite)
        @import_data,@status, @message = invite_service.import_and_invite(file,@user, "User", params[:add_user_type],invite_hash,params[:license_version], params[:data_array])
        expect(invite_service).to have_received(:import_and_invite)
        controller.instance_variable_set(:@import_data, @import_data)
        expect(assigns(:import_data)).to eq(@import_data)
      end
      it "renders the page with success response" do
        xhr :post, 'user_import_and_invite'
        expect(response).to render_template('user_import_and_invite')
      end

    end
  end

  describe "POST #update_user_status" do
    context "when import or inviting record(s)" do
      subject(:params) {{"id"=>"25", "status"=>"status", "status_text"=>"Active", "is_admin_data"=>"false"} }
      subject(:user_service) { Cloud::UserManager }

      it "assigns to @admin_user" do
        controller.instance_variable_set(:@admin_user, @user)
        expect(assigns(:admin_user)).to eq(@user)
      end

      it "checks InviteFriend class having the import_and_invite method" do
        xhr :post, 'update_user_status',  {:id => @user.id}
        expect(user_service).to respond_to(:update_user_status)
      end

      it "checks get_user_licenses method is accepting with 1 arguments" do
        xhr :post, 'update_user_status' ,  {:id => @user.id}
        expect(user_service).to respond_to(:update_user_status).with(2).argument
      end

      it "access the get_user_created_groups method and assign results to @groups" do
        xhr :post, 'user_import_and_invite',  {:id => @user.id}
        allow(user_service).to receive(:update_user_status)
        user_service.update_user_status(@user,params)
        expect(user_service).to have_received(:update_user_status)
      end
      it "renders the page with success response" do
        xhr :post, 'user_import_and_invite',  {:id => @user.id}
        expect(response).to render_template('user_import_and_invite')
      end

    end
  end



end
end
