require 'rails_helper'

module NimbusAdminEngine
  RSpec.describe ClientsController, type: :controller do
  routes { NimbusAdminEngine::Engine.routes }
  before (:each) do
    @user = FactoryGirl.create(:user)
    sign_in @user
    @client = FactoryGirl.create(:client, user_id: @user.id)
    @solution = FactoryGirl.create(:solution)
    @client_solution = FactoryGirl.create(:client_solution, client_id: @client.id,solution_id: @solution.id)
    @client_solutions_user = FactoryGirl.create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id )

    @client_attributes = FactoryGirl.attributes_for(:client, user_id: @user.id)
    @client_update_attributes = FactoryGirl.attributes_for(:client, "short_name"=>"celgenia1231", user_id: @user.id)

  end

  context "when admin user not logged in" do
    it "blocks unauthenticated access" do
      sign_in nil
      get :index
      expect(response).to redirect_to(new_user_session_path)
    end
  end

  describe "GET index" do
    context "when user logged in and viewing the company informations page" do

       it "access the client information and assign to @client" do
        get :index
        controller.instance_variable_set(:@client, @client)
        expect(assigns(:client)).to eq(@client)
      end

      it "fetch the client active licences and assign to the @licenses" do
        get :index
        controller.instance_variable_set(:@licenses, @client_solution)
        expect(assigns(:licenses)).to eq(@client_solution)
      end

      it "should render the index template" do
        get :index
        expect(response).to render_template("index")
      end
    end
  end

  describe "PUT #update" do
    context "with valid attributes" do
      subject(:client_params) {{"short_name"=>"celgenia1231"} }
      it "access the client object and assign to @client" do
        controller.instance_variable_set(:@client, @client)
        expect(assigns(:client)).to eq(@client)
      end

      it "updates the requested client information" do
        xhr :put, 'update',  {:id => @client.id,:client => client_params }
        @client.reload
      end

      it "renders the page with success response" do
        xhr :put, 'update',  {:id => @client.id,:client => client_params }
        expect(response).to render_template('update')
      end
    end

    context "with invalid attributes" do
      subject(:params) {ActionController::Parameters.new(user: { short_name: 'Francesco' })}
      it "checks incoming params containing the key client if not raise ActionController::ParameterMissing - Param not found error" do
        expect { params.require(:client) }.to raise_error(ActionController::ParameterMissing)
      end

    end
  end


end
end
