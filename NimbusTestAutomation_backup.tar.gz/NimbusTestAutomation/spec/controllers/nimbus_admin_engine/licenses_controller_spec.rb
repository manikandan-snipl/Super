require 'rails_helper'

module NimbusAdminEngine
  RSpec.describe LicensesController, type: :controller do
  routes { NimbusAdminEngine::Engine.routes }
  before (:each) do
    @user = FactoryGirl.create(:user)
    sign_in @user
    @client = FactoryGirl.create(:client, user_id: @user.id)
    @solution = FactoryGirl.create(:solution)
    @client_solution = FactoryGirl.create(:client_solution, client_id: @client.id,solution_id: @solution.id)
    @client_solutions_user = FactoryGirl.create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id )

    @client_attributes = FactoryGirl.attributes_for(:client, user_id: @user.id)
    @client_update_attributes = FactoryGirl.attributes_for(:client, "short_name"=>"celgenia1231", user_id: @user.id)

  end

  context "when admin user not logged in" do
    it "blocks unauthenticated access" do
      sign_in nil
      get :index
      expect(response).to redirect_to(new_user_session_path)
    end
  end

  describe "GET index" do
    context "when viewing the licenses page" do
      it "assigns the client data to the @client" do
        get :index
        controller.instance_variable_set(:@client, @client)
        expect(assigns(:client)).to eq(@client)
      end

      it "fetch the client active licences and assign to the @licenses" do
        get :index
        controller.instance_variable_set(:@licenses, @client_solution)
        expect(assigns(:licenses)).to eq(@client_solution)
      end

      it "assigns the empty array to the @results" do
        get :index
        controller.instance_variable_set(:@results, [])
        expect(assigns(:results)).to eq([])
      end

      it "should render the index template" do
        get :index
        expect(response).to render_template("index")
      end
    end
  end

  describe "GET search_licenses" do
    context "when user triggers the search with success response" do
      subject(:params) { {"license_version"=>"1", "license_status"=>"1", "start_date"=>"2015-09-01", "end_date"=>"2015-09-30", "tags"=>""} }
      subject(:search_class) { Cloud::CLIENT }
      it "checks search class having the get_user_licenses method" do
        xhr :get, 'search_licenses', params
        expect(search_class).to respond_to(:get_user_licenses)
      end

      it "checks get_user_licenses method is accepting with 3 arguments" do
        xhr :get, 'search_licenses', params
        expect(search_class).to respond_to(:get_user_licenses).with(6).argument
      end

      it "performs search call " do
        xhr :get, 'search_licenses', params
        allow(search_class).to receive(:get_user_licenses)
        search_class.get_user_licenses(@client, params[:license_version], params[:license_status],params[:start_date],params[:end_date],params[:query])
        expect(search_class).to have_received(:get_user_licenses)
      end

      it "renders the search_filter template with search results" do
        xhr :get, 'search_licenses', params
        expect(response).to render_template('search_licenses')
      end
    end
  end

  end
end
