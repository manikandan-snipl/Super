require 'rails_helper'
require "#{Rails.root}/spec/shared/controllers/admin_users_list_examples.rb"
module NimbusAdminEngine
  RSpec.describe AdminsController, type: :controller do
  routes { NimbusAdminEngine::Engine.routes }
  before (:each) do
    @user = FactoryGirl.create(:user)
    sign_in @user
    @client = FactoryGirl.create(:client, user_id: @user.id)
    @solution = FactoryGirl.create(:solution)
    @client_solution = FactoryGirl.create(:client_solution, client_id: @client.id,solution_id: @solution.id)
    @client_solutions_user = FactoryGirl.create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id,user_license_code: @user.invite_code )
  end

  context "when admin user not logged in" do
    it "blocks unauthenticated access" do
      sign_in nil
      get :index
      expect(response).to redirect_to(new_user_session_path)
    end
  end

  describe "GET index" do

    context "when the page renders successfully" do
      let(:user) {@user}
      let(:client_solution) {@client_solution}

      it_behaves_like "get_admin_users"

      #it "should assign the new admin user" do
      #  get :index
      #  expect(assigns(:admin_user)).to be_new_record
      #  expect(assigns(:admin_user)).to be_a User
      #end
      #
      #it "should render the index template" do
      #  get :index
      #  expect(response).to render_template("index")
      #end
    end

    context "when the page renders with failures" do
      #let(:user) {@user}
      #let(:client_solution) {@client_solution}
      #
      #it_behaves_like "get_admin_users with failures"
      #
      #it "should render the index template" do
      #  get :index
      #  expect(response).to render_template("index")
      #end
    end

  end

  #describe "GET admin_start" do
  #  context "when user logged in and viewing the landing page" do
  #    subject(:invite1) { FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email) }
  #    subject(:invite2) { FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email) }
  #    subject(:invite3) { FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email) }
  #    subject(:invites) { [invite1, invite2] }
  #
  #    subject(:users){ invites.map{|invite| FactoryGirl.create(:user, first_name: invite.first_name, last_name: invite.last_name, email: invite.email_to, invite_code: invite.invite_code)}}
  #    subject(:admin_users){ [FactoryGirl.create(:user, first_name: invite3.first_name, last_name: invite3.last_name, email: invite3.email_to, invite_code: invite3.invite_code,admin: true)]}
  #
  #    subject(:groups) { 4.times { FactoryGirl.create(:group_chat, created_by: @user.id) } }
  #
  #    it "has to fetch invite_codes from invites sent by current_users" do
  #      get :admin_start
  #      controller.instance_variable_set(:@invite_codes, [invite1.id,invite2.id])
  #      expect(assigns(:invite_codes)).to eq([invite1.id,invite2.id])
  #    end
  #
  #    it "has to display the non admin users count based on invite codes sent and accepted by the current user" do
  #      get :admin_start
  #      controller.instance_variable_set(:@users, users.count)
  #      expect(assigns(:users)).to eq(users.count)
  #    end
  #
  #    it "has to display the admin users count based on invite codes sent and accepted by the current user" do
  #      get :admin_start
  #      controller.instance_variable_set(:@admin_users, admin_users.count)
  #      expect(assigns(:admin_users)).to eq(admin_users.count)
  #    end
  #
  #    it "has to display the groups count for the client" do
  #      get :admin_start
  #      controller.instance_variable_set(:@groups, groups)
  #      expect(assigns(:groups)).to eq(groups)
  #    end
  #
  #    it "has to display the number of active licenses count for the client" do
  #      get :admin_start
  #      controller.instance_variable_set(:@licenses, [@client_solution].count)
  #      expect(assigns(:licenses)).to eq([@client_solution].count)
  #    end
  #
  #    it "should render the admin_start template" do
  #      get :admin_start
  #      expect(response).to render_template("admin_start")
  #    end
  #  end
  #end
  #
  #
  #describe "GET search_filter" do
  #  context "when user is searching with the keyword " do
  #    subject(:params) { {"query"=>"W", "model_class"=>"User", "data_view"=>"section", "search_page"=>"users", "is_admin"=>"true"} }
  #    subject(:model_class) { params["model_class"].constantize }
  #
  #    it "assigns the model class from the parameters" do
  #      xhr :get, 'search_filter', params
  #      controller.instance_variable_set(:@model, model_class)
  #      expect(assigns(:model)).to eq(model_class)
  #    end
  #
  #    it "checks the model class having the search method" do
  #      xhr :get, 'search_filter', params
  #      expect(model_class).to respond_to(:by_search_filter).with(4).argument
  #    end
  #
  #    it "calls the search method into the model class" do
  #      xhr :get, 'search_filter', params
  #      allow(model_class).to receive(:by_search_filter)
  #      model_class.by_search_filter(params[:query],@user, params[:is_admin])
  #      expect(model_class).to have_received(:by_search_filter)
  #    end
  #
  #    it "renders the search_filter template with search results" do
  #      xhr :get, 'search_filter', params
  #      expect(response).to render_template('search_filter')
  #    end
  #  end
  #end
  #
  #
  #describe "GET get_group_users_data" do
  #  context "when user chosen the group" do
  #    subject(:group) {FactoryGirl.create(:group_chat, created_by: @user.id) }
  #    subject(:group_users) {[@user].map{|user| FactoryGirl.create(:group_user, group_chat_id: group.id, user_id: user.id) } }
  #
  #    it "filters the group users to the specific group" do
  #      xhr :get, 'get_group_users_data', {"group_id" => "1" }
  #      controller.instance_variable_set(:@group_users, group_users)
  #      expect(assigns(:group_users)).to eq(group_users)
  #    end
  #
  #    it "renders the search_filter template with search results" do
  #      xhr :get, 'get_group_users_data', {"group_id" => "1" }
  #      expect(response).to render_template('get_group_users_data')
  #    end
  #  end
  #end
  #
  #describe "POST update_invite_user_status" do
  #  subject(:invite1) { FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email) }
  #  subject(:invite2) { FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email) }
  #  subject(:invited_users) {[invite1,invite2].map{|id|   id.id}.join(",")}
  #
  #  context "when user trying to update the status off the invited existing records" do
  #    subject(:params) { {"oper"=>"del", "id"=> invited_users} }
  #    subject(:model_class) { Cloud::INVITE_FRIEND }
  #
  #    it "checks the params[:id] is not starting with import_" do
  #      xhr :post, 'update_invite_user_status', params
  #      allow(model_class).to receive(:update_invite_status)
  #      expect(model_class).to respond_to(:update_invite_status).with(3).argument
  #    end
  #
  #    it "updates the status of given records" do
  #      xhr :post, 'update_invite_user_status', params
  #      allow(model_class).to receive(:update_invite_status)
  #      model_class.update_invite_status(@user,[], params)
  #      expect(model_class).to have_received(:update_invite_status)
  #    end
  #
  #    it "renders the template with success" do
  #      xhr :post, 'update_invite_user_status',params
  #      expect(response).to render_template('update_invite_user_status')
  #    end
  #  end
  #
  #  context "when user is trying to update the status of imported records" do
  #    subject(:params) { {"first_name"=>"user123", "last_name"=>"2", "email"=>"a@gmail.com", "phone_number"=>"456", "oper"=>"edit", "id"=>"import_1"} }
  #
  #    it "checks the the params id starts with import_" do
  #      xhr :get, 'update_invite_user_status', params
  #    end
  #
  #    it "wont perform the update just renders the template" do
  #      xhr :post, 'update_invite_user_status',params
  #      expect(response).to render_template('update_invite_user_status')
  #    end
  #  end
  #end
end
end
