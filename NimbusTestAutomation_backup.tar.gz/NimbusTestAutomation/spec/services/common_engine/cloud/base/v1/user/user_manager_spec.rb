require 'rails_helper'

describe Cloud::Base::V1::User::UserManager do
  subject {Cloud::Base::V1::User::UserManager}

  describe "public class methods" do
    context "responds to its methods" do
      it { expect(subject).to respond_to(:timeline_data_for_user) }
      it { expect(subject).to respond_to(:get_auto_complete_data) }
      it { expect(subject).to respond_to(:update_user_status) }
      it { expect(subject).to respond_to(:get_user_accepted_invites) }
    end
  end

  describe '#get_user_accepted_invites' do
    before (:each) do
      @user = FactoryGirl.create(:user)
      @client = FactoryGirl.create(:client, user_id: @user.id)
      @solution = FactoryGirl.create(:solution)
      @client_solution = FactoryGirl.create(:client_solution, client_id: @client.id,solution_id: @solution.id)
      @client_solutions_user = FactoryGirl.create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id )
    end
    context "when execute method with success" do

      before (:each) do
        @invite1 = FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email)
        @invite2 =  FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email)
        @invites = [@invite1, @invite2]
        @users = @invites.map{|invite| FactoryGirl.create(:user, first_name: invite.first_name, last_name: invite.last_name, email: invite.email_to, invite_code: invite.invite_code)}
      end

      it 'checks the class is having the get_invite_codes_by_user method' do
        expect(subject).to respond_to(:get_user_accepted_invites)
      end

      it 'checks get_invite_codes_by_user method is accepting with 3 arguments' do
        expect(subject).to respond_to(:get_user_accepted_invites).with(3).argument
      end

      it 'checks method parameter should be a User instance' do
        expect( @user).to be_a User
      end

      it 'checks method parameter should not be a new record' do
        expect( @user).not_to be_new_record
      end

      it "returns the user accepted invites records of non admin users with is_admin param is set to false" do
        invite_codes = [@invite1.invite_code,@invite2.invite_code]
        expect(subject.get_user_accepted_invites(invite_codes,@user, false)).to eq(@users)
      end

      it "returns the empty result as if there is no admin users ,with is_admin param is set to true" do
        invite_codes = [@invite1.invite_code,@invite2.invite_code]
        expect(subject.get_user_accepted_invites(invite_codes,@user, true)).to be_empty
      end


    end

    context "when execute method with failures" do
      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.get_user_accepted_invites}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than three parameters passed" do
        expect {subject.get_user_accepted_invites("","", "", "")}.to raise_error(ArgumentError)
      end
    end

    it "should raise an ArgumentError error if less than three parameters passed" do
      expect {subject.get_user_accepted_invites("","")}.to raise_error(ArgumentError)
    end

  end

  describe '#get_auto_complete_data' do
    before (:each) do
      @user = FactoryGirl.create(:user)
      @client = FactoryGirl.create(:client, user_id: @user.id)
      @solution = FactoryGirl.create(:solution)
      @client_solution = FactoryGirl.create(:client_solution, client_id: @client.id,solution_id: @solution.id)
      @client_solutions_user = FactoryGirl.create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id )
    end

    context "when execute method with success" do

      it 'checks the class is having the get_invite_codes_by_user method' do
        expect(subject).to respond_to(:get_auto_complete_data)
      end

      it 'checks get_invite_codes_by_user method is accepting with 2 arguments' do
        expect(subject).to respond_to(:get_auto_complete_data).with(2).argument
      end

      it 'checks method parameter should be a User instance' do
        expect(@user).to be_a User
      end

      it 'checks method parameter should not be a new record' do
        expect(@user).not_to be_new_record
      end

      context "matching letters" do
        before (:each) do
          @invite1 = FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email, first_name: "Vel", last_name: "Pradeep")
          @invite2 =  FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email)
          @invites = [@invite1, @invite2]
          @users = @invites.map{|invite| FactoryGirl.create(:user, first_name: invite.first_name, last_name: invite.last_name, email: invite.email_to, invite_code: invite.invite_code)}
        end

        it "returns an array" do
          expect(subject.get_auto_complete_data("Vel",@user)).to be_a(Array)
        end

        it "returns a array of matched users list" do
          expect(subject.get_auto_complete_data("Vel",@user)).to have(1).items
        end

        it "returns a array is not to be empty" do
          expect(subject.get_auto_complete_data("Vel",@user)).not_to be_empty
        end
      end

      context "non matching letters" do
        it {expect(subject.get_auto_complete_data("ZZAA",@user)).to be_a(Array)}
        it {expect(subject.get_auto_complete_data("ZZAA",@user)).to be_empty}
      end
    end

    context "when execute method with failures" do
      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.get_auto_complete_data}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than two parameters passed" do
        expect {subject.get_auto_complete_data("","", "")}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if less than two parameters passed" do
        expect {subject.get_auto_complete_data("")}.to raise_error(ArgumentError)
      end
    end

  end

  describe '#update_user_status' do
    before (:each) do
      @user = FactoryGirl.create(:user)
      @client = FactoryGirl.create(:client, user_id: @user.id)
      @solution = FactoryGirl.create(:solution)
      @client_solution = FactoryGirl.create(:client_solution, client_id: @client.id,solution_id: @solution.id)
      @client_solutions_user = FactoryGirl.create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id )
    end
    context "when execute method with success" do

      before (:each) do
        @invite1 = FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email)
        @invite2 =  FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email)
        @invites = [@invite1, @invite2]
        @users = @invites.map{|invite| FactoryGirl.create(:user, first_name: invite.first_name, last_name: invite.last_name, email: invite.email_to, invite_code: invite.invite_code)}
      end

      it 'checks the class is having the get_invite_codes_by_user method' do
        expect(subject).to respond_to(:update_user_status)
      end

      it 'checks get_invite_codes_by_user method is accepting with 2 arguments' do
        expect(subject).to respond_to(:update_user_status).with(2).argument
      end

      it 'checks method parameter should be a User instance' do
        expect( @user).to be_a User
      end

      it 'checks method parameter should not be a new record' do
        expect( @user).not_to be_new_record
      end

      context "updates the User as Admin if params['status'] == 'admin' "  do
        let(:params) {{"id"=>"25", "status"=>"admin", "status_text"=>"Make Admin"}}
        it "updates the user record and returns true" do
          expect(subject.update_user_status(@user, params)).to be true
        end

        it "changes the admin flag as true for the after successfull update" do
          subject.update_user_status(@user, params)
          expect(@user.admin).to eq(true)
        end
      end

      context "updates the User as Topic Guru if params['status'] == 'topic_guru' "  do
        let(:params) {{"id"=>"25", "status"=>"topic_guru", "status_text"=>"Make TopicGuru"}}
        it "updates the user record and returns true" do
          expect(subject.update_user_status(@user, params)).to be true
        end

        it "changes the user_type of the user as Topic Guru after successfull update" do
          subject.update_user_status(@user, params)
          expect(@user.user_type).to eq(TOPIC_PROVIDER)
        end
      end

      context "Assign New Licenses to the User, if params['status'] == 'assign_license' "  do
        let(:params) {{"id"=>"25", "status"=>"admin", "status_text"=>"Assign New License"}}
        it "updates the user record and returns true" do
          expect(subject.update_user_status(@user, params)).to be true
        end
      end

      context "Remove Licenses to the User, if params['status'] == 'remove_license' "  do
        let(:params) {{"id"=>"25", "status"=>"admin", "status_text"=>"Revoke License"}}
        it "updates the user record and returns true" do
          expect(subject.update_user_status(@user, params)).to be true
        end
      end

      context "updates the User status as Active if params['status'] == 'status' "  do
        let(:params) {{"id"=>"25", "status"=>"status", "status_text"=>"Active"}}
        it "updates the user record and returns true" do
          expect(subject.update_user_status(@user, params)).to be true
        end

        it "changes the status of the user as Active after successfull update" do
          subject.update_user_status(@user, params)
          expect(@user.status).to eq(USER_STATUS[params[:status_text]])
        end
      end

      context "updates the User status as Suspended if params['status'] == 'status' "  do
        let(:params) {{"id"=>"25", "status"=>"status", "status_text"=>"Suspended"}}
        it "updates the user record and returns true" do
          expect(subject.update_user_status(@user, params)).to be true
        end

        it "changes the status of the user as Suspended after successfull update" do
          subject.update_user_status(@user, params)
          expect(@user.status).to eq(USER_STATUS[params[:status_text]])
        end
      end

      context "updates the User status as Deleted if params['status'] == 'status' "  do
        let(:params) {{"id"=>"25", "status"=>"status", "status_text"=>"Deleted"}}
        it "updates the user record and returns true" do
          expect(subject.update_user_status(@user, params)).to be true
        end

        it "changes the status of the user as Deleted after successfull update" do
          subject.update_user_status(@user, params)
          expect(@user.status).to eq(USER_STATUS[params[:status_text]])
        end
      end

      context "updates the User status as Archieved if params['status'] == 'status' "  do
        let(:params) {{"id"=>"25", "status"=>"status", "status_text"=>"Archieved"}}
        it "updates the user record and returns true" do
          expect(subject.update_user_status(@user, params)).to be true
        end

        it "changes the status of the user as Active after successfull update" do
          subject.update_user_status(@user, params)
          expect(@user.status).to eq(USER_STATUS[params[:status_text]])
        end
      end
    end

    context "when execute method with failures" do
      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.update_user_status}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than two parameters passed" do
        expect {subject.update_user_status("","", "")}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if less than two parameters passed" do
        expect {subject.update_user_status("")}.to raise_error(ArgumentError)
      end

    end
  end
end
