require 'rails_helper'

describe Cloud::Base::V1::Invitation::InvitationCode do
  subject {Cloud::Base::V1::Invitation::InvitationCode}

  describe "public class methods" do
      context "responds to its methods" do
        it { expect(subject).to respond_to(:verify_invitation_code) }
        it { expect(subject).to respond_to(:get_invite_codes_by_user) }
      end
  end

  describe '#verify_invitation_code' do
    context "when execute method with success" do
      let(:user) {FactoryGirl.create(:user)}

      it 'checks the class is having the get_invite_codes_by_user method' do
        expect(subject).to respond_to(:verify_invitation_code)
      end

      it 'checks get_invite_codes_by_user method is accepting with 1 arguments' do
        expect(subject).to respond_to(:verify_invitation_code).with(1).argument
      end

      it "returns a record with VERIFIED_INVITATION status with the given invitation code" do
        @invite = FactoryGirl.create(:invite, from_id: user.id, email_from: user.email, status: VERIFIED_INVITATION)
         collection = Invite.where(invite_code: @invite.invite_code,status: VERIFIED_INVITATION)
         expect(collection).to have(1).record
      end
    end

    context "when execute method with failures" do
      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.verify_invitation_code}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than one parameters passed" do
        expect {subject.verify_invitation_code("","")}.to raise_error(ArgumentError)
      end
    end

  end

   describe '#get_invite_codes_by_user' do
    context "when execute method with success" do
      let(:user) {FactoryGirl.create(:user)}

      it 'checks the class is having the get_invite_codes_by_user method' do
       expect(subject).to respond_to(:get_invite_codes_by_user)
      end

      it 'checks get_invite_codes_by_user method is accepting with 1 arguments' do
        expect(subject).to respond_to(:get_invite_codes_by_user).with(1).argument
      end

      it 'checks method parameter should be a User instance' do
        expect(user).to be_a User
      end

      it 'checks method parameter should not be a new record' do
        expect(user).not_to be_new_record
      end

      it "returns a result as an array" do
        invite1 = FactoryGirl.create(:invite, from_id: user.id, email_from: user.email, status: CONFIRM_INVITATION)
        invite2 = FactoryGirl.create(:invite, from_id: user.id, email_from: user.email,status: CONFIRM_INVITATION)
        expect(subject.get_invite_codes_by_user(user)).to be_instance_of(Array)
      end

      it "returns an array of results that match CONFIRM_INVITATION status and invites sent by the user" do
        invite1 = FactoryGirl.create(:invite, from_id: user.id, email_from: user.email, status: CONFIRM_INVITATION)
        invite2 = FactoryGirl.create(:invite, from_id: user.id, email_from: user.email,status: CONFIRM_INVITATION)
        expect(subject.get_invite_codes_by_user(user)) == ([invite1.invite_code, invite1.invite_code])
      end

      it "returns an empty array of results, If records not matched CONFIRM_INVITATION status and invites sent by the user" do
        invite1 = FactoryGirl.create(:invite, from_id: user.id, email_from: user.email, status: VERIFIED_INVITATION)
        invite2 = FactoryGirl.create(:invite, from_id: user.id, email_from: user.email,status: VERIFIED_INVITATION)
        expect(subject.get_invite_codes_by_user(user)) == ([])
      end

    end

    context "when execute method with failures" do
      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.get_invite_codes_by_user}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than one parameters passed" do
        expect {subject.get_invite_codes_by_user("","")}.to raise_error(ArgumentError)
      end

      it 'should raise an Error, if invalid parameters passed' do
        expect {subject.get_invite_codes_by_user("")}.to raise_error(NoMethodError)
      end

    end

  end
end
