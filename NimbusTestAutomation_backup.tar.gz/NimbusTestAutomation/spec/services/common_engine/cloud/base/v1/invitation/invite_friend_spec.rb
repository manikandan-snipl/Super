require 'rails_helper'
require 'csv'
describe Cloud::Base::V1::Invitation::InviteFriend do
  subject {Cloud::Base::V1::Invitation::InviteFriend}

  before (:each) do
    @user = FactoryGirl.create(:user)
    @member = FactoryGirl.create(:member)
    @client = FactoryGirl.create(:client, user_id: @user.id)
    @solution = FactoryGirl.create(:solution)
    @client_solution = FactoryGirl.create(:client_solution, client_id: @client.id,solution_id: @solution.id)
    @client_solutions_user = FactoryGirl.create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id )
  end

  describe "public class methods" do
    context "responds to its methods" do
      it { expect(subject).to respond_to(:sending_invitation) }
      it { expect(subject).to respond_to(:get_invited) }
      it { expect(subject).to respond_to(:get_invites_data) }
      it { expect(subject).to respond_to(:update_invite_status) }
      it { expect(subject).to respond_to(:import_and_invite) }
      it { expect(subject).to respond_to(:generate_array_data) }
      it { expect(subject).to respond_to(:send_invitation) }
    end
  end

  describe '#import_and_invite' do

    context "when execute method with success" do

      let(:import_list) {[]}
      let(:import_count) {0}
      let(:error_count) {0}
      let(:invitation) {""}
      let(:errors_list) {""}

      context "if the file param is found (CSV File is uploaded) and insert_type is not equal to 'invite' " do

        let(:file) {fixture_file_upload('files/invites.csv')}
        let(:numrows) { CSV.readlines(file).size }

        context "checks the license count of the license version of client" do
          it "returns the license_count of the license version" do
            dbl = double(subject, :get_license_count => Cloud::CLIENT_MANAGER.get_solution_licenses_count(@user, "1"))
            #allow(dbl).to receive(:get_license_count).with(@user, "1").and_return(@client_solution.license_max_limit)
            expect(dbl.get_license_count).to eq(@client_solution.license_max_limit - ClientSolutionsUser.count)
            expect(dbl.get_license_count).not_to be_nil
          end
        end

        context "when client license_max_limit is greater than Zero(0)" do
          #let(:license_count) {Client.get_license_count(@user, "license_version")}
          let(:license_count) {Cloud::CLIENT_MANAGER.get_solution_licenses_count(@user, "1")}
          let(:count) {license_count > numrows - 1}

          context "client license_max_limit is greater than total count of csv rows" do
            it "parses the csv file" do
              csv_data = CSV.foreach(file, headers: true).each {|row| import_list.push(row.to_hash)}
              expect(license_count).to be > numrows-1
              expect(count).to be true
            end

            it "should import the the records and sends invitation to the imported users" do
              csv_data = CSV.foreach(file, headers: true).each {|row| import_list.push(row.to_hash)}
              count = Invite.count
              invitation, errors_list= subject.send_invitation(import_list,@user,'',true,"User")
              expect(invitation).to eq(import_list)
              expect( Invite.count).to eq(count + import_list.length)
            end

            it "returns the result includes import_list, status, imported records hash " do
              csv_data = CSV.foreach(file, headers: true).each {|row| import_list.push(row.to_hash)}
              status = {import_count: import_list.length, error_count: "", max_license_limit_error_message: nil}
              result = subject.import_and_invite(file, @user, "User", "import", "", 1, "")
              expect(result[0]).not_to be_empty
              expect(result[0]).to match_array(import_list)
              expect(result[1][:import_count]).to eq(import_list.length)
              expect(result[1][:max_license_limit_error_message]).to be_nil
            end

          end

          context "client license_max_limit is lesser than total count of csv rows" do
            let(:file) {fixture_file_upload('files/invites_exceed_row.csv')}

            let(:error_msg) {I18n.t("IMPORT_USER_ERROR_CODES.UPLOAD_LICENSE_MAX_LIMIT_ERRRO")}
            it "skips the CSV file and returns error message" do
              result = subject.import_and_invite(file, @user, "User", "import", "", "1", "")
              expect(result[0]).to be_empty
              expect(result[0]).to match_array([])
              expect(result[1][:import_count]).to eq(0)
              expect(result[1][:max_license_limit_error_message]).to eq(error_msg)
            end
          end
        end

        context "if the license count is equal to Zero(0)" do
          let(:error_msg) {I18n.t("IMPORT_USER_ERROR_CODES.LICENSE_MAX_LIMIT_ERRRO")}
          it "skips the CSV file and returns error message" do
            result = subject.import_and_invite(file, User.new, "User", "import", "", "", "")
            expect(result[0]).to be_empty
            expect(result[0]).to match_array([])
            expect(result[1][:import_count]).to eq(0)
            expect(result[1][:max_license_limit_error_message]).to eq(error_msg)
          end

        end
      end

      context "if data array params is passed " do

        let(:data_array) {{"0"=>{"first_name"=>"user", "last_name"=>"2", "license_code"=>"dfdf4", "email"=>"a@gmail.com", "phone_number"=>"456"}}}
        let(:import_list) {[{"first_name"=>"user", "last_name"=>"2", "license_code"=>"dfdf4", "email"=>"a@gmail.com", "phone_number"=>"456"}]}

        it "generates the import list from array data " do
          result = subject.generate_array_data(data_array)
          expect(result).not_to be_empty
          expect(result).to match_array(import_list)
        end

        it "returns the result includes import_list, status, imported records hash" do
          result = subject.import_and_invite("", @user, "User", "", {}, 1,data_array)
          expect(result[0]).not_to be_empty
          expect(result[0]).to match_array(import_list)
          expect(result[1][:import_count]).to eq(0)
          expect(result[1][:error_count]).to eq("")
          expect(result[1][:max_license_limit_error_message]).to be_nil
          expect(result[2]).not_to be_empty
          expect(result[2]).to match_array(import_list)
        end
      end

      context "if data array params and file param is not passed " do

        let(:record) {import_list.push({"first_name"=>"test123", "last_name"=>"ee3", "email"=>"e@e.com", "phone_number"=>"4234234", "license_code"=>"dfsdfsdfsdd"})}
        let(:data_hash) {{"first_name"=>"test123", "last_name"=>"ee3", "email"=>"e@e.com", "phone_number"=>"4234234", "license_code"=>"dfsdfsdfsdd"}}
        let(:import_list) {[data_hash]}

        it "should send invite to the Invited User" do
          count = Invite.count
          invitation, errors_list = subject.send_invitation(import_list,@user,'',true,"User")
          expect(invitation).to eq(import_list)
          expect( Invite.count).to eq(count + import_list.length)
        end

        it "returns the result includes import_list, status, imported records hash" do
          result = subject.import_and_invite("", @user, "User", "invite", data_hash, 1, "")
          expect(result[0]).not_to be_empty
          expect(result[0]).to match_array(import_list)
          expect(result[1][:import_count]).to eq(0)
          expect(result[1][:error_count]).to eq("")
          expect(result[1][:max_license_limit_error_message]).to be_nil
          expect(result[2]).not_to be_empty
          expect(result[2]).to match_array(import_list)
        end

      end
    end

    context "when execute method with failures" do

      it "should raise an Failure/Error" do
        expect {subject.import_and_invite(file, @user, "User", "import", "", "0", "")}.to raise_error
      end

      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.import_and_invite}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than seven parameters passed" do
        expect {subject.import_and_invite("","", "", "", "", "", "", "")}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if less than seven parameters passed" do
        expect {subject.import_and_invite("","", "", "", "")}.to raise_error(ArgumentError)
      end

      it 'should raise an Error, if invalid parameters passed' do
        expect {subject.import_and_invite("")}.to raise_error(ArgumentError)
      end

    end
  end

  describe '#verify_invitation_code' do
    context "when execute method with success" do
      #let(:user) {FactoryGirl.create(:user)}
      it 'checks the class is having the get_invite_codes_by_user method' do
        expect(subject).to respond_to(:get_invites_data)
      end

      it 'checks get_invite_codes_by_user method is accepting with 1 arguments' do
        expect(subject).to respond_to(:get_invites_data).with(1).argument
      end

      it 'checks method parameter should be a User instance' do
        expect(@user).to be_a User
      end

      it 'checks method parameter should not be a new record' do
        expect(@user).not_to be_new_record
      end

      it "returns results that doesn't match EXPIRED_INVITATION status and invites sent by the user" do
        invite1 = FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email, status: CONFIRM_INVITATION)
        invite2 = FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email,status: CONFIRM_INVITATION)
        expect(subject.get_invites_data(@user)) == ([invite1, invite1])
      end

      it "returns an empty results, If records not matched EXPIRED_INVITATION status and invites sent by the user" do
        invite1 = FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email, status: EXPIRED_INVITATION)
        invite2 = FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email,status: EXPIRED_INVITATION)
        expect(subject.get_invites_data(@user)) == ([])
      end
    end

    context "when execute method with failures" do

      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.get_invites_data}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than one parameters passed" do
        expect {subject.get_invites_data("","")}.to raise_error(ArgumentError)
      end

      it 'should raise an Error, if invalid parameters passed' do
        expect {subject.get_invites_data("")}.to raise_error(NoMethodError)
      end

    end

  end

  describe '#update_invite_status' do
    context "when execute method with success" do
      #let(:user) {FactoryGirl.create(:user)}
      let(:invite1) {FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email, status: CONFIRM_INVITATION)}
      let(:params) {{"oper"=>"del", "id"=>"#{invite1.id}"}}
      let(:test_params) {{"first_name"=>"user", "last_name"=>"02", "email"=>"a@gmail.com", "phone_number"=>"456", "oper"=>"edit", "id"=>"#{invite1.id}"}}
      let(:data_array) {[{}]}

      it 'checks the class is having the update_invite_status method' do
        expect(subject).to respond_to(:update_invite_status)
      end

      it 'has to check method is accepting with 3 arguments' do
        expect(subject).to respond_to(:update_invite_status).with(3).argument
      end
      it 'checks method parameter should be a User instance' do
        expect(@user).to be_a User
      end

      it 'checks method parameter should not be a new record' do
        expect(@user).not_to be_new_record
      end

      it 'finds the resource and update the status as INACTIVE if params[:oper] is  "del"' do
        invite_ids = params["id"].split(",")
        invite_ids.each {|i|
          record = Invite.where(id: i).first
          expect(record).to eq(invite1)
          record.update_attributes(status: INACTIVE) if params[:oper] == "del"
        }
      end

      it 'finds the resource and not update the status as INACTIVE if params[:oper] is not "del"' do
        invite_ids = test_params["id"].split(",")
        invite_ids.each {|i|
          record = Invite.where(id: i).first
          expect(record).to eq(invite1)
          record.update(first_name: test_params[:first_name],last_name: test_params[:last_name],email_to: test_params[:email],phone_number: test_params[:phone_number] ) if test_params[:oper] != "del"
        }
      end
    end
  end

  describe '#generate_array_data' do
    context "when execute method with success" do
      let(:data_array) { {"0"=>{"first_name"=>"user", "last_name"=>"2", "license_code"=>"dfdf4", "email"=>"a@gmail.com", "phone_number"=>"456"}}}

      it 'checks the class is having the generate_array_data method' do
        expect(subject).to respond_to(:generate_array_data)
      end

      it 'checks method is accepting with 1 arguments' do
        expect(subject).to respond_to(:generate_array_data).with(1).argument
      end

      it "returns a result as an array from the given data array" do
        expect(subject.generate_array_data(data_array)).to eq([{"first_name"=>"user", "last_name"=>"2", "license_code"=>"dfdf4", "email"=>"a@gmail.com", "phone_number"=>"456"}])
      end

      it "returns a result as an array" do
        expect(subject.generate_array_data(data_array)).to be_instance_of(Array)
      end

    end

    context "when execute method with failures" do

      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.generate_array_data}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than one parameters passed" do
        expect {subject.generate_array_data("","")}.to raise_error(ArgumentError)
      end

      it 'should raise an Error, if invalid parameters passed' do
        expect {subject.generate_array_data("")}.to raise_error(NoMethodError)
      end
    end
  end
end
