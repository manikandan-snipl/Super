require 'rails_helper'

describe Cloud::Base::V1::GroupChat::GroupUserManager do
  subject {Cloud::Base::V1::GroupChat::GroupUserManager}
  before (:each) do
    @user = FactoryGirl.create(:user)
    @member = FactoryGirl.create(:member)
    @client = FactoryGirl.create(:client, user_id: @user.id)
    @solution = FactoryGirl.create(:solution)
    @client_solution = FactoryGirl.create(:client_solution, client_id: @client.id,solution_id: @solution.id)
    @client_solutions_user = FactoryGirl.create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id )
  end

  describe "public class methods" do
    context "responds to its methods" do
      it { expect(subject).to respond_to(:add_member) }
      it { expect(subject).to respond_to(:remove_member) }
      it { expect(subject).to respond_to(:list_group_members) }
      it { expect(subject).to respond_to(:member_groups) }
      it { expect(subject).to respond_to(:recent_chat_peers) }
    end
  end

  describe '#add_member' do
    context "when execute method with success" do
      let(:group) {FactoryGirl.create(:group_chat, created_by: @user.id)}
      let(:member_id) {[@user.id]}

      it 'checks the class is having the get_all_groups method' do
        expect(subject).to respond_to(:add_member)
      end

      it 'checks the method is accepting with 3 arguments' do
        expect(subject).to respond_to(:add_member).with(3).argument
      end

      it 'checks member_id parameter should be a Array' do
        expect(member_id).to be_a(Array)
      end

      context "If current_member_or_user parameter is User" do
        let(:current_member_or_user) {@user}

        it 'checks current_member_or_user parameter should be a User instance' do
          expect(current_member_or_user).to be_a User
        end

        it 'checks current_member_or_user parameter should not be a new record' do
          expect(current_member_or_user).not_to be_new_record
        end

        it "should create a group user record if current_member_or_user class is User" do
          subject.add_member(member_id,group.id,current_member_or_user )
          expect(GroupUser).to have(member_id.length).items
        end

        it "matches the group chat record with given groupchat_id param" do
          group_chat_id = group.id
          expect(group).to eq(GroupChat.where(id: group_chat_id.to_i,status: ACTIVE).first)
        end

        it "checks the existence of record given record with the given group_chat_id param" do
          group_chat_id = group.id
          expect(GroupChat.where(id: group_chat_id.to_i,status: ACTIVE)).to exist
        end

        it "checks the given record is not to be exist with given invalid group_chat_id" do
          group_chat_id = "MS"
          expect(GroupChat.where(id: group_chat_id.to_i,status: ACTIVE)).not_to exist
        end
      end

      context "If current_member_or_user parameter is Member" do
        let(:current_member_or_user) {@member}
        it 'checks current_member_or_user parameter should be a Member instance' do
          expect(current_member_or_user).to be_a Member
        end

        it 'checks current_member_or_user parameter should not be a new record' do
          expect(current_member_or_user).not_to be_new_record
        end

        it "should create a group member record if current_member_or_user class is Member" do
          subject.add_member(member_id,group.id,current_member_or_user )
          expect(GroupMember).to have(member_id.length).items
        end
      end
    end

    context "when execute method with failures" do
      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.add_member}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if less than three parameters passed" do
        expect {subject.add_member("","")}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than three parameters passed" do
        expect {subject.add_member("","", "", "")}.to raise_error(ArgumentError)
      end

      it "should raise an NoMethodError if member_id param is not passing as array" do
        expect {subject.add_member("",1, @user)}.to raise_error(NoMethodError)
      end
    end
  end

  describe '#remove_member' do

    context "when execute method with success" do
      it 'checks the class is having the remove_member method' do
        expect(subject).to respond_to(:remove_member)
      end

      it 'checks the method is accepting with 3 arguments' do
        expect(subject).to respond_to(:remove_member).with(3).argument
      end

      context "If current_member_or_user parameter is User" do
        let(:group) {FactoryGirl.create(:group_chat, created_by: @user.id)}
        let(:member_id) {[@user.id]}
        let(:current_member_or_user) {@user}

        before (:each) do
          @invite1 = FactoryGirl.create(:invite, from_id: @user.id, email_from: @user.email, first_name: "Vel", last_name: "Pradeep")
          @invites = [@invite1]
          @users = @invites.map{|invite| FactoryGirl.create(:user, first_name: invite.first_name, last_name: invite.last_name, email: invite.email_to, invite_code: invite.invite_code)}
          @users_list = @users.push(@user)
          @group_users = @users_list.map{|user| FactoryGirl.create(:group_user, group_chat_id: group.id, user_id: user.id, created_by: user.id) }
        end

        it 'checks current_member_or_user parameter should be a User instance' do
          expect(current_member_or_user).to be_a User
        end

        it 'checks current_member_or_user parameter should not be a new record' do
          expect(current_member_or_user).not_to be_new_record
        end

        it "checks the existence of GroupUser with the given member_id & group_chat_id param" do
          group_chat_id = group.id
          record = GroupUser.where(user_id: member_id,group_chat_id: group_chat_id,status: ACTIVE)
          expect(record).to exist
        end

        it "checks the given GroupUser is not to be exist with given invalid group_chat_id" do
          group_chat_id = "MS"
          expect(GroupUser.where(user_id: member_id,group_chat_id: group_chat_id,status: ACTIVE)).not_to exist
        end

        it "shows the group user status as ACTIVE before remove member" do
          record = GroupUser.where(user_id: member_id,group_chat_id: group.id,status: ACTIVE).first
          expect(record.status).to eq(ACTIVE)
        end

        it "updates the group_user status as ACTIVE to INACTIVE" do
          group_chat_id = group.id
          subject.remove_member(member_id,group.id,current_member_or_user )
          aft_update = GroupUser.where(user_id: member_id,group_chat_id: group_chat_id).first
          expect(aft_update.status).to eq(INACTIVE)
        end

        context "If the group is created by the given member_id" do

          it "updates new admin for the group from the active users of the group" do
            new_admin = group.active_group_users.last.try(:user_id)
            subject.remove_member(member_id,group.id,current_member_or_user )
            expect(group.created_by).to eq(new_admin)
          end
        end

        context "If the group is not created by the given member_id " do
          it "updates the updated_at time " do
            expect(group.updated_at).not_to eql(Time.now)
            subject.remove_member(@users.last.id,group.id,current_member_or_user )
          end
        end
      end

      context "If current_member_or_user parameter is Member" do
        let(:group) {FactoryGirl.create(:group_chat, created_by: @member.id)}
        let(:member_id) {[@member.id]}
        let(:current_member_or_user) {@member}

        before (:each) do
          @members = [1].map{ |invite| FactoryGirl.create(:member)}
          @members_list = @members.push(@member)
          @group_members = @members_list.map{|user| FactoryGirl.create(:group_member, group_chat_id: group.id, member_id: user.id, created_by: user.id) }
        end

        it 'checks current_member_or_user parameter should be a User instance' do
          expect(current_member_or_user).to be_a Member
        end

        it 'checks current_member_or_user parameter should not be a new record' do
          expect(current_member_or_user).not_to be_new_record
        end

        it "checks the existence of GroupMember with the given member_id & group_chat_id param" do
          group_chat_id = group.id
          record = GroupMember.where(member_id: member_id,group_chat_id: group_chat_id,status: ACTIVE)
          expect(record).to exist
        end

        it "checks the given GroupMember is not to be exist with given invalid group_chat_id" do
          group_chat_id = "MS"
          expect(GroupMember.where(member_id: member_id,group_chat_id: group_chat_id,status: ACTIVE)).not_to exist
        end

        it "shows the group member status as ACTIVE before remove member" do
          record = GroupMember.where(member_id: member_id,group_chat_id: group.id,status: ACTIVE).first
          expect(record.status).to eq(ACTIVE)
        end

        it "updates the member status as ACTIVE to INACTIVE" do
          group_chat_id = group.id
          subject.remove_member(member_id,group.id,current_member_or_user )
          aft_update = GroupMember.where(member_id: member_id,group_chat_id: group_chat_id).first
          expect(aft_update.status).to eq(INACTIVE)
        end

        context "If the group is created by the given member_id" do

          it "updates new admin for the group from the active members of the group" do
            new_admin = group.active_group_members.last.try(:member_id)
            subject.remove_member(member_id,group.id,current_member_or_user )
            expect(group.created_by).to eq(new_admin)
          end
        end

        context "If the group is not created by the given member_id " do
          it "updates the updated_at time " do
            expect(group.updated_at).not_to eql(Time.now)
            subject.remove_member(@members.last.id,group.id,current_member_or_user )
          end
        end
      end
    end

    context "when execute method with failures" do
      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.remove_member}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if less than three parameters passed" do
        expect {subject.remove_member("","")}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than three parameters passed" do
        expect {subject.remove_member("","", "", "")}.to raise_error(ArgumentError)
      end

      it "should raise an NoMethodError if group_chat_id param is empty string" do
        expect {subject.remove_member("","", @user)}.to raise_error(NoMethodError)
      end
    end
  end
end

