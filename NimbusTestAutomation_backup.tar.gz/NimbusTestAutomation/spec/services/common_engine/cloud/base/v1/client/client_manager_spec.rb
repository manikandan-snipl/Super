require 'rails_helper'

describe Cloud::Base::V1::Client::ClientManager do
  subject {Cloud::Base::V1::Client::ClientManager}
  describe "public class methods" do

    context "responds to its methods" do
      it { expect(subject).to respond_to(:load_client_info) }
      it { expect(subject).to respond_to(:get_client) }
      it { expect(subject).to respond_to(:get_client_active_licenses) }
      it { expect(subject).to respond_to(:get_user_licenses) }
      it { expect(subject).to respond_to(:get_user_license_code) }
      it { expect(subject).to respond_to(:get_client_licenses_count) }
    end
  end

  describe '#get_client' do
    context "when execute method with success" do
      let(:user) {FactoryGirl.create(:user)}
      let(:client) {FactoryGirl.create(:client, user_id: user.id)}
      let(:solution) {FactoryGirl.create(:solution)}
      let(:client_solution) {FactoryGirl.create(:client_solution, client_id: client.id,solution_id: solution.id)}
      let(:client_solutions_user) {FactoryGirl.create(:client_solutions_user, user_id: user.id, client_solution_id: client_solution.id )}

      it 'checks the class is having the get_client method' do
        expect(subject).to respond_to(:get_client)
      end

      it 'checks get_invite_codes_by_user method is accepting with 1 arguments' do
        expect(subject).to respond_to(:get_client).with(1).argument
      end

      it 'checks method parameter should be a User instance' do
        expect(user).to be_a User
      end

      it 'checks method parameter should not be a new record' do
        expect(user).not_to be_new_record
      end

      it "finds a client solution user" do
        record = client_solutions_user
        collection = ClientSolutionsUser.where(user_id: user.id).first
        expect(collection).to eq(record)
      end

      it "returns the client object if given user have record in client solution users" do
        record = client_solutions_user
        collection = ClientSolutionsUser.where(user_id: user.id).first
        expect(subject.get_client(user)).to eq(collection.try(:client_solution).try(:client))
      end

      it "returns the empty string if given user does not have record in client solution users" do
        collection = ClientSolutionsUser.where(user_id: 0).first
        expect(subject.get_client(user)).to eq("")
      end
    end

    context "when execute method with failures" do
      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.get_client}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than one parameters passed" do
        expect {subject.get_client("","")}.to raise_error(ArgumentError)
      end

    end
  end

  describe '#get_client_active_licenses' do
    context "when execute method with success" do
      let(:user) {FactoryGirl.create(:user)}
      let(:client) {FactoryGirl.create(:client, user_id: user.id)}
      let(:solution) {FactoryGirl.create(:solution)}
      let(:client_solution) {FactoryGirl.create(:client_solution, client_id: client.id,solution_id: solution.id)}
      let(:client_solutions_user) {FactoryGirl.create(:client_solutions_user, user_id: user.id, client_solution_id: client_solution.id )}

      it 'checks the class is having the get_client method' do
        expect(subject).to respond_to(:get_client_active_licenses)
      end

      it 'checks get_invite_codes_by_user method is accepting with 1 arguments' do
        expect(subject).to respond_to(:get_client_active_licenses).with(1).argument
      end

      it 'checks method parameter should be a User instance' do
        expect(client).to be_a Client
      end

      it 'checks method parameter should not be a new record' do
        expect(client).not_to be_new_record
      end

      it 'returns the active licenses for a client' do
        allow(subject).to receive(:get_client_active_licenses)
        licenses = subject.get_client_active_licenses(client)
        expect(subject).to have_received(:get_client_active_licenses)
      end

    end

    context "when execute method with failures" do
      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.get_client}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than one parameters passed" do
        expect {subject.get_client("","")}.to raise_error(ArgumentError)
      end
      it 'should raise an Error, if invalid parameters passed' do
        expect {subject.get_client_active_licenses("")}.to raise_error(NoMethodError)
      end

    end
  end

    describe '#get_user_licenses' do
    context "when execute method with success" do

      before (:each) do
        @user = create(:user)
        @client = create(:client, user_id: @user.id)
        @solution = create(:solution)
        @client_solution = create(:client_solution, client_id: @client.id,solution_id: @solution.id, license_max_limit:'100')
        @client_solutions_user = create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id )
      end


      it 'checks the class is having the get_client method' do
        expect(subject).to respond_to(:get_user_licenses)
      end

      it 'checks get_invite_codes_by_user method is accepting with 6 arguments' do
        expect(subject).to respond_to(:get_user_licenses).with(6).argument
      end

      it 'checks method parameter should be a User instance' do
        expect(@client).to be_a Client
      end

      it 'checks method parameter should not be a new record' do
        expect(@client).not_to be_new_record
      end

      it 'returns the active licenses for a client' do
        #p subject.get_user_licenses(@client, '1','1',"2015-08-22 14:45:14","2016-10-22 14:45:14", "MS")
        allow(subject).to receive(:get_user_licenses).and_return(@client_solution.client_solutions_users)
      end

    end

    context "when execute method with failures" do
      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.get_client}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than or less than 6 parameters passed" do
        expect {subject.get_client("","")}.to raise_error(ArgumentError)
      end

    end
  end

  describe '#get_client_licenses_count' do
    context "when execute method with success" do
      before (:each) do
        @user = create(:user)
        @client = create(:client, user_id: @user.id)
        @solution = create(:solution)
        @client_solution = create(:client_solution, client_id: @client.id,solution_id: @solution.id, license_max_limit:'100')
        @client_solutions_user = create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id )
      end


      it 'checks the class is having the get_client_licenses_count method' do
        expect(subject).to respond_to(:get_client_licenses_count)
      end

      it 'checks get_invite_codes_by_user method is accepting with 1 arguments' do
        expect(subject).to respond_to(:get_client_licenses_count).with(1).argument
      end

      it 'checks method parameter should be a User instance' do
        expect(@user).to be_a User
      end

      it 'checks method parameter should not be a new record' do
        expect(@user).not_to be_new_record
      end


      it "finds the client record for the given user" do
        expect(subject.get_client(@user)).to eq(@client)
      end

      it "returns the active licenses count, if the client is available" do
        client = subject.get_client(@user)
        license_count = subject.get_client_active_licenses(client).count
        expect(subject.get_client_licenses_count(@user)).to eq(license_count)
      end

    end

    context "when execute method with failures" do
      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.get_client_licenses_count}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than or less than 1 parameters passed" do
        expect {subject.get_client_licenses_count("","")}.to raise_error(ArgumentError)
      end

      it 'should raise an Error, if invalid parameters passed' do
        expect {subject.get_client_licenses_count("")}.to raise_error(NoMethodError)
      end

    end
  end

  describe '#get_user_license_code' do
    context "when execute method with success" do
      let(:user) {FactoryGirl.create(:user)}
      let(:client) {FactoryGirl.create(:client, user_id: user.id)}
      let(:solution) {FactoryGirl.create(:solution)}
      let(:client_solution) {FactoryGirl.create(:client_solution, client_id: client.id,solution_id: solution.id)}
      let(:client_solutions_user) {FactoryGirl.create(:client_solutions_user, user_id: user.id, client_solution_id: client_solution.id )}

      it 'checks the class is having the get_client method' do
        expect(subject).to respond_to(:get_user_license_code)
      end

      it 'checks get_invite_codes_by_user method is accepting with 1 arguments' do
        expect(subject).to respond_to(:get_user_license_code).with(1).argument
      end

      it 'checks method parameter should be a User instance' do
        expect(user).to be_a User
      end

      it 'checks method parameter should not be a new record' do
        expect(user).not_to be_new_record
      end

      it "finds a client solution user" do
        record = client_solutions_user
        collection = ClientSolutionsUser.where(user_id: user.id).first
        expect(collection).to eq(record)
      end

      it "returns the user_license_code  if given user have record in client solution users" do
        record = client_solutions_user
        collection = ClientSolutionsUser.where(user_id: user.id).first
        expect(subject.get_user_license_code(user)).to eq(collection.try(:user_license_code))
      end

      it "returns the empty string if given user does not have record in client solution users" do
        collection = ClientSolutionsUser.where(user_id: 0).first
        expect(subject.get_user_license_code(user)).to eq("")
      end

    end
    context "when execute method with failures" do
      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.get_user_license_code}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than or less than 6 parameters passed" do
        expect {subject.get_user_license_code("","")}.to raise_error(ArgumentError)
      end

    end
  end

  describe '#get_solution_licenses_count' do
    before (:each) do
      @user = FactoryGirl.create(:user)
      @member = FactoryGirl.create(:member)
      @client = FactoryGirl.create(:client, user_id: @user.id)
      @solution = FactoryGirl.create(:solution)
      @client_solution = FactoryGirl.create(:client_solution, client_id: @client.id,solution_id: @solution.id)
      @client_solutions_user = FactoryGirl.create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id )
    end

    context "when execute method with success" do

      context "if the client is present" do

        it "finds the client solution record for the given license version " do
          expect(subject.get_client(@user)).to eq(@client)
          record = ClientSolution.includes(:client_solutions_users, :solution).where("client_solutions.client_id = ? and solutions.package_type =?", @client.id, "1").references(:solutions,:client_solutions_users).first
          expect(record).to eq(@client_solution)
        end

        it "finds the active users licenses If the client solution is having solution users" do
          record = ClientSolution.includes(:client_solutions_users, :solution).where("client_solutions.client_id = ? and solutions.package_type =?", @client.id, "1").references(:solutions,:client_solutions_users).first
          expect(record.client_solutions_users.where(status: ACTIVE).map(&:user_id).uniq.length).to eq(ClientSolutionsUser.count)
        end

        it "returns the unused licenses"  do
          used_licenses = ClientSolutionsUser.count
          expect(subject.get_solution_licenses_count(@user, "1")).to eq(@client_solution.license_max_limit - used_licenses )
        end
      end

      context "if the client is not present" do
        it "returns the licenses count as Zero(0)" do
          expect(subject.get_client(build(:user))).to eq("")
          expect(subject.get_solution_licenses_count(build(:user), "")).to eq(0)
        end
      end

    end

    context "when execute method with failures" do
      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.get_solution_licenses_count}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if less than 2 parameters passed" do
        expect {subject.get_solution_licenses_count("")}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than 2 parameters passed" do
        expect {subject.get_solution_licenses_count("", "", "")}.to raise_error(ArgumentError)
      end
    end
  end


end
