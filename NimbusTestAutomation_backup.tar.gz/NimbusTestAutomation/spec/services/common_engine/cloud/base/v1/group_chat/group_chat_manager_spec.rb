require 'rails_helper'

describe Cloud::Base::V1::GroupChat::GroupChatManager do
  subject {Cloud::Base::V1::GroupChat::GroupChatManager}

  before (:each) do
    @user = FactoryGirl.create(:user)
    @client = FactoryGirl.create(:client, user_id: @user.id)
    @solution = FactoryGirl.create(:solution)
    @client_solution = FactoryGirl.create(:client_solution, client_id: @client.id,solution_id: @solution.id)
    @client_solutions_user = FactoryGirl.create(:client_solutions_user, user_id: @user.id, client_solution_id: @client_solution.id )
  end

  describe "public class methods" do
    context "responds to its methods" do
      it { expect(subject).to respond_to(:create_group_chat_with_members) }
      it { expect(subject).to respond_to(:update_group_chat_info) }
      it { expect(subject).to respond_to(:update_group_chat_info_and_members) }
      it { expect(subject).to respond_to(:group_chat_info) }
      it { expect(subject).to respond_to(:get_group_chat_info) }
      it { expect(subject).to respond_to(:get_all_groups) }
      it { expect(subject).to respond_to(:get_group_users_info) }
      it { expect(subject).to respond_to(:get_user_created_groups) }
    end
  end

  describe '#get_all_groups' do

    context "when execute method with success" do
      it 'checks the class is having the get_all_groups method' do
        expect(subject).to respond_to(:get_all_groups)
      end

      it 'checks the method is accepting with 1 arguments' do
        expect(subject).to respond_to(:get_all_groups).with(1).argument
      end

      it 'checks method parameter should be a User instance' do
        expect( @user).to be_a User
      end

      it 'checks method parameter should not be a new record' do
        expect( @user).not_to be_new_record
      end

      context "matching GroupChat records" do
        before (:each) do
          @group = FactoryGirl.create(:group_chat, created_by: @user.id)
          @group_users =[@user].map{|user| FactoryGirl.create(:group_user, group_chat_id: @group.id, user_id: @user.id) }
        end

        it 'returns the all groupchat records with matched set' do
          allow(subject).to receive(:get_all_groups).and_return(@group)
        end

        it "returns matched groups list" do
          expect(subject.get_all_groups(@user)).to have(1).items
        end
      end

      context "non matching GroupChat records" do
        before (:each) do
          @group = FactoryGirl.create(:group_chat, created_by: @user.id)
        end

        it "returns empty resultset of groups list" do
          expect(subject.get_all_groups(@user)).to have(0).items
        end
      end
    end

    context "when execute method with failures" do
      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.get_all_groups}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than one parameters passed" do
        expect {subject.get_all_groups("","")}.to raise_error(ArgumentError)
      end
    end

  end

  describe '#get_group_users_info' do

    context "when execute method with success" do
      it 'checks the class is having the get_all_groups method' do
        expect(subject).to respond_to(:get_group_users_info)
      end

      it 'checks the method is accepting with 1 arguments' do
        expect(subject).to respond_to(:get_group_users_info).with(1).argument
      end

      context "matching GroupChat records" do
        before (:each) do
          @group = FactoryGirl.create(:group_chat, created_by: @user.id)
          @group_users =[@user].map{|user| FactoryGirl.create(:group_user, group_chat_id: @group.id, user_id: @user.id) }
        end

        it 'returns the all groupchat records with matched set' do
          allow(subject).to receive(:get_group_users_info).and_return(@group)
        end

        it "returns matched groups list" do
          expect(subject.get_group_users_info(@group.id)).to have(1).items
        end

      end

      context "non matching GroupChat records" do
        before (:each) do
          @group = FactoryGirl.create(:group_chat, created_by: @user.id)
        end

        it "returns empty resultset of with given group" do
          expect(subject.get_group_users_info(@group.id)).to have(0).items
        end

        it "returns empty resultset of groups list if group id is empty string" do
          expect(subject.get_group_users_info("")).to have(0).items
        end
      end
    end

    context "when execute method with failures" do
      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.get_group_users_info}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than one parameters passed" do
        expect {subject.get_group_users_info("","")}.to raise_error(ArgumentError)
      end
    end

  end

  describe '#get_user_created_groups' do
    context "when execute method with success" do
      it 'checks the class is having the get_all_groups method' do
        expect(subject).to respond_to(:get_user_created_groups)
      end

      it 'checks the method is accepting with 1 arguments' do
        expect(subject).to respond_to(:get_user_created_groups).with(1).argument
      end

      it 'checks method parameter should be a User instance' do
        expect( @user).to be_a User
      end

      it 'checks method parameter should not be a new record' do
        expect( @user).not_to be_new_record
      end


      context "matching GroupChat records" do
        before (:each) do
          @group = FactoryGirl.create(:group_chat, created_by: @user.id)
          @group_users =[@user].map{|user| FactoryGirl.create(:group_user, group_chat_id: @group.id, user_id: @user.id) }
        end

        it 'should returns the result set ' do
          allow(subject).to receive(:get_user_created_groups).and_return(@group)
        end

        it 'returns the all groupchat records with matched set' do
          expect(subject.get_user_created_groups(@user)).== @group
        end

        it "returns the one matched records" do
          expect(subject.get_user_created_groups(@user)).to have(1).items
        end
      end

      context "non matching GroupChat records" do

        it "returns empty result set of with given group" do
          expect(subject.get_user_created_groups(@user)).to have(0).items
        end
      end
    end

    context "when execute method with failures" do
      it "should raise an ArgumentError error if no parameters passed" do
        expect {subject.get_user_created_groups}.to raise_error(ArgumentError)
      end

      it "should raise an ArgumentError error if more than one parameters passed" do
        expect {subject.get_user_created_groups("","")}.to raise_error(ArgumentError)
      end

      it "should raise an NoMethodError if parameter is passed as a empty string" do
        expect {subject.get_user_created_groups("")}.to raise_error(NoMethodError)
      end
    end
  end

end
