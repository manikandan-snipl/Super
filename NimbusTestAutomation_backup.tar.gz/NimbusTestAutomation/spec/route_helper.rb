module RouteHelper
  def self.included(base)
    base.routes {NimbusAdminEngine::Engine.routes}
  end

end
