module Cloud
  # Service Helper
  SHM = Shared::Base::V1::ServiceHelperMethods
  # MEMBER
  JOIN_MANAGER = Cloud::Base::V1::Member::JoinManager
  STATUS_MANAGER = Cloud::Base::V1::Member::StatusManager
  MEMBER_MANAGER = Cloud::Base::V1::Member::MemberManager
  # MESSAGES
  CHAT_MANAGER = Cloud::Base::V1::Messages::ChatManager
  # FOLLOW
  FOLLOW_MEMBER = Cloud::Base::V1::Follow::FollowMember
  FOLLOW_TOPIC = Cloud::Base::V1::Follow::FollowTopic
  #FOLLOW_MANAGER = Cloud::Base::V1::Follow::FollowManager
  # INVITATION
  INVITATION_CODE = Cloud::Base::V1::Invitation::InvitationCode
  INVITE_FRIEND = Cloud::Base::V1::Invitation::InviteFriend
  # IMAGE
  ATTACHMENT_MANAGER = Cloud::Base::V1::Attachments::AttachmentManager
  # MEMBER_PROFILE
  MEMBER_LONG_PROFILE = Cloud::Base::V1::MemberProfile::MemberLongProfile
  MEMBER_SHORT_PROFILE = Cloud::Base::V1::MemberProfile::MemberShortProfile
  # PUBLIC_FEEDS
  COMMENT_MANAGER = Cloud::Base::V1::PublicFeeds::CommentManager
  FEED_MANAGER = Cloud::Base::V1::PublicFeeds::FeedManager
  LIKE_MANAGER = Cloud::Base::V1::PublicFeeds::LikeManager
  SHARE_MANAGER = Cloud::Base::V1::PublicFeeds::ShareManager
  TIMELINE_MANAGER = Cloud::Base::V1::PublicFeeds::TimeLineManager
  # REFERRALS
  REFERRAL_MANAGER = Cloud::Base::V1::Referrals::ReferralManager
  # SETTINGS
  APP_SETTING = Cloud::Base::V1::Settings::AppSetting
  # TOPICS
  TOPIC_MANAGER = Cloud::Base::V1::Topics::TopicManager
  # GROUP
  GROUP_CHAT_MANAGER = Cloud::Base::V1::GroupChat::GroupChatManager
  GROUP_MEMBER_MANAGER = Cloud::Base::V1::GroupChat::GroupMemberManager
  LIVE_MEET = Cloud::Base::V1::GroupChat::LiveMeet
  # FRIEND
  FRIEND_MANAGER = Cloud::Base::V1::Friends::FriendManager
  # CONTACT
  CONTACT_MANAGER = Cloud::Base::V1::Contact::ContactManager
  # GET DIRTY DATA
  NOTIFICATION_MANAGER = Cloud::Base::V1::Notifications::Notification
  # SYNC MANAGER
  SYNC_MANAGER = Cloud::Base::V1::DirtyData::SyncManager
  # SALESGURU
  DEMOGRAPHICS_MANAGER = Cloud::Base::V1::Salesguru::Demographics::DemographicsManager
  CLIENT = Cloud::Base::V1::Client::ClientManager
  UserManager = Cloud::Base::V1::User::UserManager
  GroupUserManager = Cloud::Base::V1::GroupChat::GroupUserManager
  CLIENT_MANAGER = Cloud::Base::V1::Client::ClientManager
end
