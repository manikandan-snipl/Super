module Enterprise
  # Service Helper
  SHM = Shared::Base::V1::ServiceHelperMethods
  # MEMBER
  JOIN_MANAGER = Enterprise::Base::V1::Member::JoinManager
  STATUS_MANAGER = Enterprise::Base::V1::Member::StatusManager
  MEMBER_MANAGER = Enterprise::Base::V1::Member::MemberManager
  # MESSAGES
  CHAT_MANAGER = Enterprise::Base::V1::Messages::ChatManager
  # FOLLOW
  FOLLOW_MEMBER = Enterprise::Base::V1::Follow::FollowMember
  FOLLOW_TOPIC = Enterprise::Base::V1::Follow::FollowTopic
  #FOLLOW_MANAGER = Enterprise::Base::V1::Follow::FollowManager
  # INVITATION
  INVITATION_CODE = Enterprise::Base::V1::Invitation::InvitationCode
  INVITE_FRIEND = Enterprise::Base::V1::Invitation::InviteFriend
  # IMAGE
  ATTACHMENT_MANAGER = Enterprise::Base::V1::Attachments::AttachmentManager
  # MEMBER_PROFILE
  MEMBER_LONG_PROFILE = Enterprise::Base::V1::MemberProfile::MemberLongProfile
  MEMBER_SHORT_PROFILE = Enterprise::Base::V1::MemberProfile::MemberShortProfile
  # PUBLIC_FEEDS
  COMMENT_MANAGER = Enterprise::Base::V1::PublicFeeds::CommentManager
  FEED_MANAGER = Enterprise::Base::V1::PublicFeeds::FeedManager
  LIKE_MANAGER = Enterprise::Base::V1::PublicFeeds::LikeManager
  SHARE_MANAGER = Enterprise::Base::V1::PublicFeeds::ShareManager
  TIMELINE_MANAGER = Enterprise::Base::V1::PublicFeeds::TimeLineManager
  # REFERRALS
  REFERRAL_MANAGER = Enterprise::Base::V1::Referrals::ReferralManager
  # SETTINGS
  APP_SETTING = Enterprise::Base::V1::Settings::AppSetting
  # TOPICS
  TOPIC_MANAGER = Enterprise::Base::V1::Topics::TopicManager
  # GROUP
  GROUP_CHAT_MANAGER = Enterprise::Base::V1::GroupChat::GroupChatManager
  GROUP_MEMBER_MANAGER = Enterprise::Base::V1::GroupChat::GroupMemberManager
  LIVE_MEET = Enterprise::Base::V1::GroupChat::LiveMeet
  # FRIEND
  FRIEND_MANAGER = Enterprise::Base::V1::Friends::FriendManager
  # CONTACT
  CONTACT_MANAGER = Enterprise::Base::V1::Contact::ContactManager
  # GET DIRTY DATA
  NOTIFICATION_MANAGER = Enterprise::Base::V1::Notifications::Notification
  # SYNC MANAGER
  SYNC_MANAGER = Enterprise::Base::V1::DirtyData::SyncManager
  # SALESGURU
  DEMOGRAPHICS_MANAGER = Enterprise::Base::V1::Salesguru::Demographics::DemographicsManager
  CLIENT = Enterprise::Base::V1::Client::ClientManager
end
