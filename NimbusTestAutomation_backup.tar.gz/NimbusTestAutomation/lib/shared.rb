module Shared
# Service Helper
  SHM = Shared::Base::V1::ServiceHelperMethods
  CHM = Shared::Base::V1::ClientHelperMethods
end
