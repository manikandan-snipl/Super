class AdminNotifier < ActionMailer::Base

  default from: "\"Team FaceDox\" <team@supranimbus.co>"

  #<--------FaceDox Welcome Email After member confirmation
  def welcome_email(member)
    recipients = email_recipients(member)
    @member = member
    mail(to: recipients,subject: "#{member.full_name} welcome to FaceDox")
  end

  def welcome_email_and_pwd(member,password)

    recipients = email_recipients(member)
    @member = member
    @password = password
    @link = "facedoxApp://?req_type=ResetPassword"

    mail(to: recipients,subject: "#{member.full_name} welcome to FaceDox")
  end

  #<--------Crash Email Notifier
  def exception_report(exception, backtrace, session_variables, prams, env)
    recipients = ["raji@supranimbus.co"]
    #recipients = ["jitendra.samant@cuelogic.co.in"]
    @member = "NA"
    @exception = exception
    @backtrace = backtrace
    @session_variables = session_variables
    @prams = prams
    @env = env
    mail(:to => recipients, :subject => "NimbusAPI Error"+" "+"#{exception}")
  end

  def invite(member,invite,end_date,email_to,sol="supranimbus")
    recipients = email_to
    @member = member
    @full_name = invite.first_name + " " +invite.last_name
    @end_date = end_date
    @invitation_code = invite.invite_code
    @solution = sol
    @link = "#{ApiConfig.config[:face_web_admin_path]}/member_confirmation?invite_code=#{@invitation_code}&from_id=#{member.id}&bundle_id=1&version=1"
    mail(to: recipients,subject: " welcome to #{sol}")
  end

  def invite_friends(member,email_to,invitation_code,action)
    if action == "update"
      recipients = email_recipients(member)
      from = [member.email]
      sub = "#{member.email} accepted your invitation"
      @content = "#{member.email} accepted your invitation"
    else
      if invitation_code.blank?
        recipients = [member.email,"raji@supranimbus.co"]
        from = [email_to]
        sub = "#{email_to} want to join FaceDox"
        @content = "#{email_to} want to join FaceDox"
      else
        recipients = [email_to,"raji@supranimbus.co"]
        from = [member.email]
        sub = "#{member.email} invite you to join FaceDox"
        @content = "#{member.email} invite you to join FaceDox"
      end
    end
    @invitation_code = invitation_code
    mail(to: recipients,from: from,subject: sub)
  end

  #<-------------Reset Password---------------->
  def reset_password(member,password)
    recipients = email_recipients(member)
    @member = member
    @password = password
    @link = "facedoxApp://?req_type=ResetPassword"
    mail(to: recipients,subject: "Reset you FaceDox Password")
  end

  #<---------Send email to get invited
  def get_invited_by_friend(sender_email,receiver_email)
    recipients = [receiver_email]        
    mail(to: recipients,from: sender_email,subject: "#{sender_email} want to join the FaceDox")
  end

  #<---------Update Member profile info from bigdata

  def bigdata_support(data,address,member)
    recipients = "raji@supranimbus.co"
    @member = member
    @data = data
    @address = address
    mail(to: recipients,subject: "#{@member.full_name} wants to update his profile")
  end

  def email_recipients(member)
    ["raji@supranimbus.co",member.email,"raji@supranimbus.co"]
  end

  #<--------Crash Email Notifier
  def client_report(msg,current_prod_or_solution="supranimbus",obj_or_env)
    recipients = ["raji11@supranimbus.co"]
    #recipients = ["jitendra.samant@cuelogic.co.in"]
    @msg = msg
    @current_prod_or_solution = current_prod_or_solution
    @env=obj_or_env
    mail(:to => recipients, from: set_from(current_prod_or_solution), :subject => "Client updates")
  end

  def set_from(current_prod_or_solution="supranimbus")
    "\"Team #{current_prod_or_solution}\" <team@supranimbus.co>"

  end


end
